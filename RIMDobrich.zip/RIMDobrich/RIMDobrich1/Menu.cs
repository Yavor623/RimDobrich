﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace RIMDobrich1
{
    public partial class Menu : Form
    {

        public Menu()
        {
            InitializeComponent();
        }
        private void sectionsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Sections
        {
            Menu menu = new Menu();
            Sections sections = new Sections();
            sections.Show();

            this.Hide();
            menu.Close();
        }

        private void nameOfMuseumbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра NameOfMuseum
        {
            Menu menu = new Menu();
            NameOfMuseum name = new NameOfMuseum();
            name.Show();

            this.Hide();
            menu.Close();
        }

        private void typesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Types
        {
            Menu menu = new Menu();
            Types types = new Types();
            types.Show();
            this.Hide();
            menu.Close();

        }

        private void artefactsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Artefacts
        {
            Menu menu = new Menu();
            Artefacts artefactscs = new Artefacts();
            artefactscs.Show();
            this.Hide();
            menu.Close();
        }

        private void materialsbtn_Click(object sender, EventArgs e)  //Затваря сегашния формуляр и отваря формуляра Materials
        {
            Menu menu = new Menu();
            Materials materials = new Materials();
            materials.Show();
            this.Hide();
            menu.Close();
        }

        private void queriesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Queries
        {
            Menu menu = new Menu();

            Queries queries = new Queries();
            queries.Show();
            this.Hide();
            menu.Close();
        }
        private void assesmentProtcolBtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра AssesmentProtocol
        {
            Menu menu = new Menu();
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            assesmentProtocol.Show();
            this.Hide();
            menu.Close();
        }

        private void collectionsBtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра CollectionsMuseum
        {
            CollectionsMuseum collections = new CollectionsMuseum();
            Menu menu = new Menu();

            collections.Show();
            this.Hide();
            menu.Close();
        }

        private void shapesBtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Shapes
        {
            Menu menu = new Menu();
            Shapes shapes = new Shapes();
            shapes.Show();

            this.Hide();
            menu.Close();
        }
    }
}
