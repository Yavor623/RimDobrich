﻿namespace RIMDobrich1
{
    partial class Queries
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Queries));
            queryChoiceComboBox = new ComboBox();
            queriesDataGrid = new DataGridView();
            typeOfColumnChoiceComboBox = new ComboBox();
            menuPanel = new Panel();
            assesmentProtocolBtn = new Button();
            collectionsBtn = new Button();
            museumsBtn = new Button();
            artefactsBtn = new Button();
            quieriesBtn = new Button();
            materialsBtn = new Button();
            shapesBtn = new Button();
            typesBtn = new Button();
            sectionsBtn = new Button();
            menuBtn = new Button();
            queriesBtn = new Button();
            countTxt = new TextBox();
            clearBtn = new Button();
            columnChoiceComboBox = new ComboBox();
            searchTxt = new TextBox();
            ((System.ComponentModel.ISupportInitialize)queriesDataGrid).BeginInit();
            menuPanel.SuspendLayout();
            SuspendLayout();
            // 
            // queryChoiceComboBox
            // 
            queryChoiceComboBox.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            queryChoiceComboBox.FormattingEnabled = true;
            queryChoiceComboBox.Items.AddRange(new object[] { "Изведи всички", "Изведи броя на", "Търси по" });
            queryChoiceComboBox.Location = new Point(30, 130);
            queryChoiceComboBox.Name = "queryChoiceComboBox";
            queryChoiceComboBox.Size = new Size(667, 53);
            queryChoiceComboBox.TabIndex = 41;
            queryChoiceComboBox.Text = "Изберете вида на заявката";
            queryChoiceComboBox.SelectedIndexChanged += queryChoice_SelectedIndexChanged;
            queryChoiceComboBox.KeyDown += queryChoiceComboBox_KeyDown;
            // 
            // queriesDataGrid
            // 
            queriesDataGrid.AllowUserToAddRows = false;
            queriesDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            queriesDataGrid.BackgroundColor = Color.Tan;
            queriesDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            queriesDataGrid.Location = new Point(731, 91);
            queriesDataGrid.MultiSelect = false;
            queriesDataGrid.Name = "queriesDataGrid";
            queriesDataGrid.ReadOnly = true;
            queriesDataGrid.RowHeadersWidth = 51;
            queriesDataGrid.RowTemplate.Height = 29;
            queriesDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            queriesDataGrid.Size = new Size(1135, 846);
            queriesDataGrid.TabIndex = 43;
            // 
            // typeOfColumnChoiceComboBox
            // 
            typeOfColumnChoiceComboBox.Enabled = false;
            typeOfColumnChoiceComboBox.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            typeOfColumnChoiceComboBox.FormattingEnabled = true;
            typeOfColumnChoiceComboBox.Items.AddRange(new object[] { "Секция", "Колекция", "Музей", "Вид", "Форма", "Материал" });
            typeOfColumnChoiceComboBox.Location = new Point(30, 296);
            typeOfColumnChoiceComboBox.Name = "typeOfColumnChoiceComboBox";
            typeOfColumnChoiceComboBox.Size = new Size(667, 53);
            typeOfColumnChoiceComboBox.TabIndex = 44;
            typeOfColumnChoiceComboBox.Text = "Изберете критерий за търсене";
            typeOfColumnChoiceComboBox.SelectedIndexChanged += columnChoice_SelectedIndexChanged;
            typeOfColumnChoiceComboBox.KeyDown += queryChoiceComboBox_KeyDown;
            // 
            // menuPanel
            // 
            menuPanel.BackColor = Color.Tan;
            menuPanel.Controls.Add(assesmentProtocolBtn);
            menuPanel.Controls.Add(collectionsBtn);
            menuPanel.Controls.Add(museumsBtn);
            menuPanel.Controls.Add(artefactsBtn);
            menuPanel.Controls.Add(quieriesBtn);
            menuPanel.Controls.Add(materialsBtn);
            menuPanel.Controls.Add(shapesBtn);
            menuPanel.Controls.Add(typesBtn);
            menuPanel.Controls.Add(sectionsBtn);
            menuPanel.Controls.Add(menuBtn);
            menuPanel.Location = new Point(0, 0);
            menuPanel.Name = "menuPanel";
            menuPanel.Size = new Size(1933, 38);
            menuPanel.TabIndex = 45;
            // 
            // assesmentProtocolBtn
            // 
            assesmentProtocolBtn.BackColor = Color.NavajoWhite;
            assesmentProtocolBtn.FlatAppearance.BorderSize = 0;
            assesmentProtocolBtn.FlatStyle = FlatStyle.Flat;
            assesmentProtocolBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtocolBtn.Location = new Point(1364, 0);
            assesmentProtocolBtn.Name = "assesmentProtocolBtn";
            assesmentProtocolBtn.Size = new Size(185, 35);
            assesmentProtocolBtn.TabIndex = 35;
            assesmentProtocolBtn.Text = "Оц. протокол";
            assesmentProtocolBtn.UseVisualStyleBackColor = false;
            assesmentProtocolBtn.Click += assesmentProtocolbtn_Click;
            // 
            // collectionsBtn
            // 
            collectionsBtn.BackColor = Color.NavajoWhite;
            collectionsBtn.FlatAppearance.BorderSize = 0;
            collectionsBtn.FlatStyle = FlatStyle.Flat;
            collectionsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            collectionsBtn.Location = new Point(1555, 0);
            collectionsBtn.Name = "collectionsBtn";
            collectionsBtn.Size = new Size(185, 35);
            collectionsBtn.TabIndex = 34;
            collectionsBtn.Text = "Сбирки";
            collectionsBtn.UseVisualStyleBackColor = false;
            collectionsBtn.Click += collectionsbtn_Click;
            // 
            // museumsBtn
            // 
            museumsBtn.BackColor = Color.NavajoWhite;
            museumsBtn.FlatAppearance.BorderSize = 0;
            museumsBtn.FlatStyle = FlatStyle.Flat;
            museumsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            museumsBtn.Location = new Point(1173, 0);
            museumsBtn.Name = "museumsBtn";
            museumsBtn.Size = new Size(185, 35);
            museumsBtn.TabIndex = 33;
            museumsBtn.Text = "Музеи";
            museumsBtn.UseVisualStyleBackColor = false;
            museumsBtn.Click += museumsbtn_Click;
            // 
            // artefactsBtn
            // 
            artefactsBtn.BackColor = Color.NavajoWhite;
            artefactsBtn.FlatAppearance.BorderSize = 0;
            artefactsBtn.FlatStyle = FlatStyle.Flat;
            artefactsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            artefactsBtn.Location = new Point(218, 0);
            artefactsBtn.Name = "artefactsBtn";
            artefactsBtn.Size = new Size(185, 35);
            artefactsBtn.TabIndex = 32;
            artefactsBtn.Text = "Артефакти";
            artefactsBtn.UseVisualStyleBackColor = false;
            artefactsBtn.Click += artefactsbtn_Click;
            // 
            // quieriesBtn
            // 
            quieriesBtn.BackColor = Color.NavajoWhite;
            quieriesBtn.Enabled = false;
            quieriesBtn.FlatAppearance.BorderSize = 0;
            quieriesBtn.FlatStyle = FlatStyle.Flat;
            quieriesBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            quieriesBtn.Location = new Point(1745, 0);
            quieriesBtn.Name = "quieriesBtn";
            quieriesBtn.Size = new Size(166, 35);
            quieriesBtn.TabIndex = 31;
            quieriesBtn.Text = "Заявки";
            quieriesBtn.UseVisualStyleBackColor = false;
            // 
            // materialsBtn
            // 
            materialsBtn.BackColor = Color.NavajoWhite;
            materialsBtn.FlatAppearance.BorderSize = 0;
            materialsBtn.FlatStyle = FlatStyle.Flat;
            materialsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            materialsBtn.Location = new Point(982, 0);
            materialsBtn.Name = "materialsBtn";
            materialsBtn.Size = new Size(185, 35);
            materialsBtn.TabIndex = 30;
            materialsBtn.Text = "Материали";
            materialsBtn.UseVisualStyleBackColor = false;
            materialsBtn.Click += materialsbtn_Click;
            // 
            // shapesBtn
            // 
            shapesBtn.BackColor = Color.NavajoWhite;
            shapesBtn.FlatAppearance.BorderSize = 0;
            shapesBtn.FlatStyle = FlatStyle.Flat;
            shapesBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            shapesBtn.Location = new Point(791, 0);
            shapesBtn.Name = "shapesBtn";
            shapesBtn.Size = new Size(185, 35);
            shapesBtn.TabIndex = 29;
            shapesBtn.Text = "Форми";
            shapesBtn.UseVisualStyleBackColor = false;
            shapesBtn.Click += shapesbtn_Click;
            // 
            // typesBtn
            // 
            typesBtn.BackColor = Color.NavajoWhite;
            typesBtn.FlatAppearance.BorderSize = 0;
            typesBtn.FlatStyle = FlatStyle.Flat;
            typesBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            typesBtn.Location = new Point(600, 0);
            typesBtn.Name = "typesBtn";
            typesBtn.Size = new Size(185, 35);
            typesBtn.TabIndex = 28;
            typesBtn.Text = "Видове артефакти";
            typesBtn.UseVisualStyleBackColor = false;
            typesBtn.Click += typesbtn_Click;
            // 
            // sectionsBtn
            // 
            sectionsBtn.BackColor = Color.NavajoWhite;
            sectionsBtn.FlatAppearance.BorderSize = 0;
            sectionsBtn.FlatStyle = FlatStyle.Flat;
            sectionsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            sectionsBtn.Location = new Point(409, 0);
            sectionsBtn.Name = "sectionsBtn";
            sectionsBtn.Size = new Size(185, 35);
            sectionsBtn.TabIndex = 2;
            sectionsBtn.Text = "Отдели";
            sectionsBtn.UseVisualStyleBackColor = false;
            sectionsBtn.Click += sectionsbtn_Click;
            // 
            // menuBtn
            // 
            menuBtn.BackColor = Color.NavajoWhite;
            menuBtn.FlatAppearance.BorderSize = 0;
            menuBtn.FlatStyle = FlatStyle.Flat;
            menuBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            menuBtn.Location = new Point(0, 0);
            menuBtn.Name = "menuBtn";
            menuBtn.Size = new Size(212, 35);
            menuBtn.TabIndex = 0;
            menuBtn.Text = "Меню";
            menuBtn.UseVisualStyleBackColor = false;
            menuBtn.Click += menubtn_Click;
            // 
            // queriesBtn
            // 
            queriesBtn.BackColor = Color.NavajoWhite;
            queriesBtn.FlatStyle = FlatStyle.Flat;
            queriesBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            queriesBtn.Location = new Point(30, 781);
            queriesBtn.Name = "queriesBtn";
            queriesBtn.Size = new Size(667, 75);
            queriesBtn.TabIndex = 46;
            queriesBtn.Text = "Старт";
            queriesBtn.UseVisualStyleBackColor = false;
            queriesBtn.Click += queriesbtn_Click;
            // 
            // countTxt
            // 
            countTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            countTxt.Location = new Point(30, 572);
            countTxt.Multiline = true;
            countTxt.Name = "countTxt";
            countTxt.PlaceholderText = "Брой";
            countTxt.ReadOnly = true;
            countTxt.Size = new Size(667, 60);
            countTxt.TabIndex = 47;
            countTxt.TabStop = false;
            countTxt.KeyDown += queryChoiceComboBox_KeyDown;
            // 
            // clearBtn
            // 
            clearBtn.BackColor = Color.NavajoWhite;
            clearBtn.FlatStyle = FlatStyle.Flat;
            clearBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            clearBtn.Location = new Point(30, 862);
            clearBtn.Name = "clearBtn";
            clearBtn.Size = new Size(667, 75);
            clearBtn.TabIndex = 49;
            clearBtn.Text = "Изчисти";
            clearBtn.UseVisualStyleBackColor = false;
            clearBtn.Click += clearBtn_Click;
            // 
            // columnChoiceComboBox
            // 
            columnChoiceComboBox.DropDownHeight = 250;
            columnChoiceComboBox.Enabled = false;
            columnChoiceComboBox.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            columnChoiceComboBox.FormattingEnabled = true;
            columnChoiceComboBox.IntegralHeight = false;
            columnChoiceComboBox.Location = new Point(30, 441);
            columnChoiceComboBox.Name = "columnChoiceComboBox";
            columnChoiceComboBox.Size = new Size(667, 53);
            columnChoiceComboBox.TabIndex = 50;
            columnChoiceComboBox.Text = "Изберете колона";
            columnChoiceComboBox.KeyDown += queryChoiceComboBox_KeyDown;
            // 
            // searchTxt
            // 
            searchTxt.Enabled = false;
            searchTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            searchTxt.Location = new Point(30, 682);
            searchTxt.Multiline = true;
            searchTxt.Name = "searchTxt";
            searchTxt.PlaceholderText = "Търсачка";
            searchTxt.Size = new Size(667, 60);
            searchTxt.TabIndex = 85;
            // 
            // Queries
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 205, 153);
            ClientSize = new Size(1902, 1055);
            Controls.Add(columnChoiceComboBox);
            Controls.Add(clearBtn);
            Controls.Add(countTxt);
            Controls.Add(queriesBtn);
            Controls.Add(menuPanel);
            Controls.Add(typeOfColumnChoiceComboBox);
            Controls.Add(queriesDataGrid);
            Controls.Add(queryChoiceComboBox);
            Controls.Add(searchTxt);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Queries";
            Text = "Заявки";
            Load += Queries_Load;
            ((System.ComponentModel.ISupportInitialize)queriesDataGrid).EndInit();
            menuPanel.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private ComboBox queryChoiceComboBox;
        private DataGridView queriesDataGrid;
        private ComboBox typeOfColumnChoiceComboBox;
        private Panel menuPanel;
        private Button assesmentProtocolBtn;
        private Button collectionsBtn;
        private Button museumsBtn;
        private Button artefactsBtn;
        private Button quieriesBtn;
        private Button materialsBtn;
        private Button shapesBtn;
        private Button typesBtn;
        private Button sectionsBtn;
        private Button menuBtn;
        private Button queriesBtn;
        private TextBox countTxt;
        private Button clearBtn;
        private ComboBox columnChoiceComboBox;
        private TextBox searchTxt;
    }
}