﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace RIMDobrich1
{
    public partial class Artefacts : Form
    {
        //Задава стойности и инициализира променливи, нужни за свързване с базата от данни и провеждане на действия в нея 
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        DataTable sqlDT = new DataTable();
        String sqlQuery;
        MySqlDataAdapter DtA = new MySqlDataAdapter();
        MySqlDataReader sqlRd;
        DataSet DS = new DataSet();

        String server = "127.0.0.1";
        String username = "root";
        String password = "";
        String database = "rim_dobrich";
        String pictureName = "";
        String chosenPictureAddress = Directory.GetCurrentDirectory();
        String fullDirection = "";
        String path;

        public Artefacts()
        {
            InitializeComponent();
        }
        private void SetFontAndColors() //Задава фонта и цвета на dataGridView
        {
            this.artefactsDataGrid.DefaultCellStyle.Font = new Font("Gabriola", 15);
            this.artefactsDataGrid.DefaultCellStyle.BackColor = Color.Beige;
            this.artefactsDataGrid.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.artefactsDataGrid.DefaultCellStyle.SelectionBackColor = Color.NavajoWhite;
            this.artefactsDataGrid.GridColor = Color.BlueViolet;
        }
        public void UploadData() //Избира данните от таблицата artefacts плюс данни от другите таблици и ги изкарва в dataGridView
        {

            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};convert zero datetime=true";
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            sqlCmd.CommandText = "SELECT id AS 'Номер',rim_dobrich.nameofmuseum.museum_name AS 'Музей',rim_dobrich.sections.section_name AS 'Отдел',rim_dobrich.collections.collection_name AS 'Сбирка' ,rim_dobrich.types.type_name AS 'Вид',artefact_name AS 'Име',cipher AS 'Шифър',dateofregistration AS 'Дата на регистрация',oldinventoryid AS 'Стар инвентарен номер',idofactofadmission AS 'Номер на акт за приемане',rim_dobrich.description.shape_name AS 'Форма',rim_dobrich.materials.material_name AS 'Материал',technology AS 'Техника',inscriptionordate AS 'Надписи или дати', size AS 'Размер',weight AS 'Тегло',era AS 'Епоха',conditionofartefact AS 'Състояние',amountoftheartefact AS 'Брой на артефакта',historicalenquiryid AS 'Историческа справка' ,sellerordonater AS 'Продавач или дарител',assesmentprotocol_id AS 'Номер на оц.протокол' ,rim_dobrich.assesmentprotocol.assesmentpr_date AS 'Дата на оц.протокол',rim_dobrich.assesmentprotocol.assesmentpr_price AS 'Сума на оц.протокол',storagelocation_id AS 'Местосъхранение',locationoffinding AS 'Местонахождение',idofphotonegative AS 'Номер на фотонегатива',registrationidofNMF AS 'Регистрационен номер на НМФ',bibliographicenquiry AS 'Библиографска справка',scientificpublications AS 'Научни публикации',conservationandrestorationid AS 'Консервация и реставрация',participationinexhibitions AS 'Участие в изложби',copiesmade AS 'Направени копия',marriageprotocolandactofliquidation AS 'Протокол за брак и акт за ликвидация',madethescientificpassport AS 'Изготвил научния паспорт',dateofcreationofthescientificpassport AS 'Дата на създаване на НП',identification AS 'Идентификация',pictureaddress AS 'Адрес на снимката' FROM rim_dobrich.artefacts  " +
            "LEFT JOIN rim_dobrich.sections ON rim_dobrich.sections.section_id =rim_dobrich.artefacts.section_id " +
            "LEFT JOIN rim_dobrich.types ON rim_dobrich.types.type_id = rim_dobrich.artefacts.type_id " +
            "LEFT JOIN rim_dobrich.nameofmuseum ON rim_dobrich.nameofmuseum.museum_id = rim_dobrich.artefacts.museum_id " +
            "LEFT JOIN rim_dobrich.description ON rim_dobrich.description.shape_id=rim_dobrich.artefacts.shape_id " +
            "LEFT JOIN rim_dobrich.collections ON rim_dobrich.collections.collection_id = rim_dobrich.artefacts.collection_id " +
            "LEFT JOIN rim_dobrich.assesmentprotocol ON rim_dobrich.assesmentprotocol.assesmentpr_id=rim_dobrich.artefacts.assesmentprotocol_id " +
            "LEFT JOIN rim_dobrich.materials ON rim_dobrich.materials.material_id=rim_dobrich.artefacts.material_id;";

            sqlRd = sqlCmd.ExecuteReader();
            sqlDT.Load(sqlRd);
            sqlRd.Close();
            sqlConn.Close();

            artefactsDataGrid.DataSource = sqlDT;


        }
        public void UploadComboBoxDataAssesmentProtocol()  //Добавя елементите на комбобокса от таблицата assesmentprotocol
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};convert zero datetime=true";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.assesmentprotocol"; //Избира всичко от таблицата assesmentprotocol
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                assesmentProtocolIdComboBox.Items.Add(reader.GetInt16("assesmentpr_id")); //Добавя елементите от колоната assesmentpr_id в комбобокса
            }
            sqlConn.Close();
        }
        public void UploadComboBoxDataCollections() //Добавя елементите на комбобокса от таблицата description
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};convert zero datetime=true";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.collections"; //Избира всичко от таблицата collections
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                collectionscb.Items.Add(reader.GetString("collection_name")); //Добавя елементите от колоната collection_name в комбобокса
            }
            sqlConn.Close();
        }
        public void UploadComboBoxDataShapes() //Добавя елементите на комбобокса от таблицата description
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};convert zero datetime=true";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.description"; //Избира всичко от таблицата description
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                shapeComboBox.Items.Add(reader.GetString("shape_name")); //Добавя елементите от колоната shape_name в комбобокса
            }
            sqlConn.Close();
        }
        public void UploadComboBoxDataMaterials() //Добавя елементите на комбобокса от таблицата materials
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database} ;convert zero datetime=true";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.materials"; //Избира всичко от таблицата materials
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                materialComboBox.Items.Add(reader.GetString("material_name")); //Добавя елементите от колоната material_name в комбобокса
            }
            sqlConn.Close();
        }
        public void UploadComboBoxDataNameOfMuseum() //Добавя елементите на комбобокса от таблицата nameofmuseum
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};convert zero datetime=true";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.nameofmuseum"; //Избира всичко от таблицата nameofmuseum
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                nameOfMuseumComboBox.Items.Add(reader.GetString("museum_name")); //Добавя елементите от колоната museum_name в комбобокса
            }
            sqlConn.Close();
        }

        public void UploadComboBoxDataSections()  //Добавя елементите на комбобокса от таблицата sections
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database} ;convert zero datetime=true";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.sections"; //Избира всичко от таблицата sections
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                sectionsComboBox.Items.Add(reader.GetString("section_name")); //Добавя елементите от колоната section_name в комбобокса
            }
            sqlConn.Close();
        }
        public void UploadComboBoxTypes() //Добавя елементите на комбобокса от таблицата types
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};convert zero datetime=true";

            sqlCmd.CommandText = "SELECT * FROM rim_dobrich.types"; //Избира всичко от таблицата types
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            MySqlDataReader reader = sqlCmd.ExecuteReader();
            while (reader.Read())
            {
                typeComboBox.Items.Add(reader.GetString("type_name")); //Добавя елементите от колоната type_name в комбобокса
            }
            sqlConn.Close();
        }

        private void addNewbtn_Click(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database} ;convert zero datetime=true";
            sqlConn.Open();
            try
            {
                //Превръща индекса на избрания елемент в индекса на съответната таблица
                int nameOfMuseumId = nameOfMuseumComboBox.SelectedIndex + 1;
                int sectionsId = sectionsComboBox.SelectedIndex + 1;
                int typesId = typeComboBox.SelectedIndex + 1;
                int shapesId = shapeComboBox.SelectedIndex + 1;
                int materialsId = materialComboBox.SelectedIndex + 1;
                int collectionsId = collectionscb.SelectedIndex + 1;
                string idAssesmentProtocol = assesmentProtocolIdComboBox.SelectedItem.ToString();
                Convert.ToInt16(idAssesmentProtocol);

                //Вмъква в таблицата artefacts съответните стойности
                sqlQuery = $"INSERT INTO rim_dobrich.artefacts(id,museum_id,section_id ,collection_id,type_id ,artefact_name,cipher,dateofregistration,oldinventoryid,idofactofadmission,shape_id,material_id,technology,inscriptionordate,size,weight,era,conditionofartefact,amountoftheartefact,historicalenquiryid,sellerordonater,assesmentprotocol_id," +
                    $"storagelocation_id,locationoffinding,idofphotonegative" +
                    $",registrationidofNMF,bibliographicenquiry,scientificpublications,conservationandrestorationid,participationinexhibitions,copiesmade,marriageprotocolandactofliquidation,madethescientificpassport,dateofcreationofthescientificpassport" +
                    $",identification,pictureaddress) " +
                    $"VALUES('{indexTxt.Text}','{nameOfMuseumId}','{sectionsId}','{collectionsId}','{typesId}','{artefactNameTxt.Text}','{cipherTxt.Text}','{dateOfRegistration.Text}','{oldInventoryIdTxt.Text}'," +
                    $"'{idOfActOfAdmissionTxt.Text}','{shapesId}','{materialsId}','{techniqueTxt.Text}','{inscriptionOrDateTxt.Text}','{sizeTxt.Text}','{weightTxt.Text}','{eraTxt.Text}','{conditionOfArtefactTxt.Text}','{amountOfArtefactTxt.Text}','{historicalEnquiryTxt.Text}'," +
                    $"'{sellerOrDonaterTxt.Text}','{idAssesmentProtocol}','{storageLocationTxt.Text}','{locationOfFindingTxt.Text}','{idOfPhotoNegativeTxt.Text}','{registrationIdOfNMFTxt.Text}','{bibliographicEnquiryTxt.Text}','{scientificPublicationsTxt.Text}','{conservationAndRestorationTxt.Text}','{participationInExhibitionsTxt.Text}'," +
                    $"'{copiesMadeTxt.Text}','{marriageProtocolAndActOfLiquidationTxt.Text}','{madeTheScientificPassportTxt.Text}','{dateOfCreationOfTheScientificPassportTxt.Text}','{identificationTxt.Text}','{pictureName}')";

                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();


                MessageBox.Show($"Успешно добавяне на {artefactNameTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                indexTxt.Text = string.Empty;
                nameOfMuseumComboBox.Text = "Име на музей";
                sectionsComboBox.Text = "Отдели";
                collectionscb.Text = "Сбирки";
                typeComboBox.Text = "Видове артефакти";
                artefactNameTxt.Text = string.Empty;
                cipherTxt.Text = string.Empty;
                dateOfAssesmentProtocol.Text = string.Empty;
                oldInventoryIdTxt.Text = string.Empty;
                idOfActOfAdmissionTxt.Text = string.Empty;
                shapeComboBox.Text = "Форма";
                materialComboBox.Text = "Материал";
                techniqueTxt.Text = string.Empty;
                inscriptionOrDateTxt.Text = string.Empty;
                sizeTxt.Text = string.Empty;
                weightTxt.Text = string.Empty;
                eraTxt.Text = string.Empty;
                conditionOfArtefactTxt.Text = string.Empty;
                amountOfArtefactTxt.Text = string.Empty;
                historicalEnquiryTxt.Text = string.Empty;
                sellerOrDonaterTxt.Text = string.Empty;
                assesmentProtocolIdComboBox.Text = "№ ОП";
                dateOfRegistration.Text = string.Empty;
                priceOfAssesmentProtocolTxt.Text = string.Empty;
                storageLocationTxt.Text = string.Empty;
                locationOfFindingTxt.Text = string.Empty;
                idOfPhotoNegativeTxt.Text = string.Empty;
                registrationIdOfNMFTxt.Text = string.Empty;
                bibliographicEnquiryTxt.Text = string.Empty;
                scientificPublicationsTxt.Text = string.Empty;
                conservationAndRestorationTxt.Text = string.Empty;
                participationInExhibitionsTxt.Text = string.Empty;
                copiesMadeTxt.Text = string.Empty;
                marriageProtocolAndActOfLiquidationTxt.Text = string.Empty;
                madeTheScientificPassportTxt.Text = string.Empty;
                dateOfCreationOfTheScientificPassportTxt.Text = string.Empty;
                identificationTxt.Text = string.Empty;
                pictureBox.ImageLocation = string.Empty;

                UploadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно добавяне на {artefactNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};";
            sqlConn.Open();
            try
            {
                //Превръща индекса на избрания елемент в индекса на съответната таблица
                int nameOfMuseumId = nameOfMuseumComboBox.SelectedIndex + 1;
                int sectionsId = sectionsComboBox.SelectedIndex + 1;
                int typesId = typeComboBox.SelectedIndex + 1;
                int shapesId = shapeComboBox.SelectedIndex + 1;
                int materialsId = materialComboBox.SelectedIndex + 1;
                int collectionsId = collectionscb.SelectedIndex + 1;
                string idAssesmentProtocol = assesmentProtocolIdComboBox.SelectedItem.ToString();
                Convert.ToInt16(idAssesmentProtocol);

                MySqlCommand sqlCmd = new MySqlCommand();
                sqlCmd.Connection = sqlConn;

                //Обновява таблицата artefacts 
                sqlCmd.CommandText = $"UPDATE rim_dobrich.artefacts SET id=@id,museum_id=@museum_id,section_id=@section_id ,collection_id=@collection_id,type_id=@type_id ,artefact_name=@artefact_name,cipher=@cipher,dateofregistration=@dateofregistration," +
                    $"oldinventoryid=@oldinventoryid,idofactofadmission=@idofactofadmission,shape_id=@shape_id,material_id=@material_id,technology=@technology,inscriptionordate=@inscriptionordate,size=@size,weight=@weight,era=@era,conditionofartefact=@conditionofartefact_id,amountoftheartefact=@amountoftheartefact,historicalenquiryid=@historicalenquiry_id" +
                    $",sellerordonater=@sellerordonater,assesmentprotocol_id=@assesmentprotocol_id,storagelocation_id=@storagelocation_id,locationoffinding=@locationoffinding,idofphotonegative=@idofphotonegative,registrationidofNMF=@registrationidofNMF," +
                    $"bibliographicenquiry=@bibliographicenquiry,scientificpublications=@scientificpublications,conservationandrestorationid=@conservationandrestoration_id,participationinexhibitions=@participationinexhibitions" +
                    $",copiesmade=@copiesmade,marriageprotocolandactofliquidation=@marriageprotocolandactofliquidation,madethescientificpassport=@madethescientificpassport,dateofcreationofthescientificpassport=@dateofcreationofthescientificpassport ,identification=@identification,pictureaddress=@pictureaddress  WHERE id=@id";
                sqlCmd.CommandType = CommandType.Text;

                //Стойностите, които ще заменят старите при обновяването
                sqlCmd.Parameters.AddWithValue("@id", indexTxt.Text);
                sqlCmd.Parameters.AddWithValue("@museum_id", nameOfMuseumId);
                sqlCmd.Parameters.AddWithValue("@section_id", sectionsId);
                sqlCmd.Parameters.AddWithValue("@collection_id", collectionsId);
                sqlCmd.Parameters.AddWithValue("@type_id", typesId);
                sqlCmd.Parameters.AddWithValue("@artefact_name", artefactNameTxt.Text);
                sqlCmd.Parameters.AddWithValue("@cipher", cipherTxt.Text);
                sqlCmd.Parameters.AddWithValue("@dateofregistration", dateOfRegistration.Text);
                sqlCmd.Parameters.AddWithValue("@oldinventoryid", oldInventoryIdTxt.Text);
                sqlCmd.Parameters.AddWithValue("@idofactofadmission", idOfActOfAdmissionTxt.Text);
                sqlCmd.Parameters.AddWithValue("@shape_id", shapesId);
                sqlCmd.Parameters.AddWithValue("@material_id", materialsId);
                sqlCmd.Parameters.AddWithValue("@technology", techniqueTxt.Text);
                sqlCmd.Parameters.AddWithValue("@inscriptionordate", inscriptionOrDateTxt.Text);
                sqlCmd.Parameters.AddWithValue("@size", sizeTxt.Text);
                sqlCmd.Parameters.AddWithValue("@weight", weightTxt.Text);
                sqlCmd.Parameters.AddWithValue("@era", eraTxt.Text);
                sqlCmd.Parameters.AddWithValue("@conditionofartefact_id", conditionOfArtefactTxt.Text);
                sqlCmd.Parameters.AddWithValue("@amountoftheartefact", amountOfArtefactTxt.Text);
                sqlCmd.Parameters.AddWithValue("@historicalenquiry_id", historicalEnquiryTxt.Text);
                sqlCmd.Parameters.AddWithValue("@sellerordonater", sellerOrDonaterTxt.Text);
                sqlCmd.Parameters.AddWithValue("@assesmentprotocol_id", idAssesmentProtocol);
                sqlCmd.Parameters.AddWithValue("@storagelocation_id", storageLocationTxt.Text);
                sqlCmd.Parameters.AddWithValue("@locationoffinding", locationOfFindingTxt.Text);
                sqlCmd.Parameters.AddWithValue("@idofphotonegative", idOfPhotoNegativeTxt.Text);
                sqlCmd.Parameters.AddWithValue("@registrationidofNMF", registrationIdOfNMFTxt.Text);
                sqlCmd.Parameters.AddWithValue("@bibliographicenquiry", bibliographicEnquiryTxt.Text);
                sqlCmd.Parameters.AddWithValue("@scientificpublications", scientificPublicationsTxt.Text);
                sqlCmd.Parameters.AddWithValue("@conservationandrestoration_id", conservationAndRestorationTxt.Text);
                sqlCmd.Parameters.AddWithValue("@participationinexhibitions", participationInExhibitionsTxt.Text);
                sqlCmd.Parameters.AddWithValue("@copiesmade", copiesMadeTxt.Text);
                sqlCmd.Parameters.AddWithValue("@marriageprotocolandactofliquidation", marriageProtocolAndActOfLiquidationTxt.Text);
                sqlCmd.Parameters.AddWithValue("@madethescientificpassport", madeTheScientificPassportTxt.Text);
                sqlCmd.Parameters.AddWithValue("@dateofcreationofthescientificpassport", dateOfCreationOfTheScientificPassportTxt.Text);
                sqlCmd.Parameters.AddWithValue("@identification", identificationTxt.Text);
                sqlCmd.Parameters.AddWithValue("@pictureaddress", pictureName);

                sqlCmd.ExecuteNonQuery();
                sqlConn.Close();

                MessageBox.Show($"Успешно обновяне на {artefactNameTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                indexTxt.Text = string.Empty;
                nameOfMuseumComboBox.Text = "Име на музей";
                sectionsComboBox.Text = "Отдели";
                collectionscb.Text = "Сбирки";
                typeComboBox.Text = "Видове артефакти";
                artefactNameTxt.Text = string.Empty;
                cipherTxt.Text = string.Empty;
                dateOfAssesmentProtocol.Text = string.Empty;
                oldInventoryIdTxt.Text = string.Empty;
                idOfActOfAdmissionTxt.Text = string.Empty;
                shapeComboBox.Text = "Форма";
                materialComboBox.Text = "Материал";
                techniqueTxt.Text = string.Empty;
                inscriptionOrDateTxt.Text = string.Empty;
                sizeTxt.Text = string.Empty;
                weightTxt.Text = string.Empty;
                eraTxt.Text = string.Empty;
                conditionOfArtefactTxt.Text = string.Empty;
                amountOfArtefactTxt.Text = string.Empty;
                historicalEnquiryTxt.Text = string.Empty;
                sellerOrDonaterTxt.Text = string.Empty;
                assesmentProtocolIdComboBox.Text = "№ ОП";
                dateOfRegistration.Text = string.Empty;
                priceOfAssesmentProtocolTxt.Text = string.Empty;
                storageLocationTxt.Text = string.Empty;
                locationOfFindingTxt.Text = string.Empty;
                idOfPhotoNegativeTxt.Text = string.Empty;
                registrationIdOfNMFTxt.Text = string.Empty;
                bibliographicEnquiryTxt.Text = string.Empty;
                scientificPublicationsTxt.Text = string.Empty;
                conservationAndRestorationTxt.Text = string.Empty;
                participationInExhibitionsTxt.Text = string.Empty;
                copiesMadeTxt.Text = string.Empty;
                marriageProtocolAndActOfLiquidationTxt.Text = string.Empty;
                madeTheScientificPassportTxt.Text = string.Empty;
                dateOfCreationOfTheScientificPassportTxt.Text = string.Empty;
                identificationTxt.Text = string.Empty;
                pictureBox.ImageLocation = string.Empty;

                UploadData();


            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно обновяване на {artefactNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void deletebtn_Click(object sender, EventArgs e)
        {
            try
            {
                sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};convert zero datetime=true";
                sqlConn.Open();
                sqlCmd.Connection = sqlConn;

                //Премахва от таблицата artefacts реда, който отговаря на индекса на селектирания ред в dataGridView
                sqlQuery = $"DELETE FROM rim_dobrich.artefacts WHERE id={indexTxt.Text};";

                MessageBox.Show($"Успешно изтриване на {artefactNameTxt.Text}", "", MessageBoxButtons.OK);
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();

                //Връща началните стойности, занулира
                indexTxt.Text = string.Empty;
                nameOfMuseumComboBox.Text = "Име на музей";
                sectionsComboBox.Text = "Отдели";
                collectionscb.Text = "Сбирки";
                typeComboBox.Text = "Видове артефакти";
                artefactNameTxt.Text = string.Empty;
                cipherTxt.Text = string.Empty;
                dateOfAssesmentProtocol.Text = string.Empty;
                oldInventoryIdTxt.Text = string.Empty;
                idOfActOfAdmissionTxt.Text = string.Empty;
                shapeComboBox.Text = "Форма";
                materialComboBox.Text = "Материал";
                techniqueTxt.Text = string.Empty;
                inscriptionOrDateTxt.Text = string.Empty;
                sizeTxt.Text = string.Empty;
                weightTxt.Text = string.Empty;
                eraTxt.Text = string.Empty;
                conditionOfArtefactTxt.Text = string.Empty;
                amountOfArtefactTxt.Text = string.Empty;
                historicalEnquiryTxt.Text = string.Empty;
                sellerOrDonaterTxt.Text = string.Empty;
                assesmentProtocolIdComboBox.Text = "№ ОП";
                dateOfRegistration.Text = string.Empty;
                priceOfAssesmentProtocolTxt.Text = string.Empty;
                storageLocationTxt.Text = string.Empty;
                locationOfFindingTxt.Text = string.Empty;
                idOfPhotoNegativeTxt.Text = string.Empty;
                registrationIdOfNMFTxt.Text = string.Empty;
                bibliographicEnquiryTxt.Text = string.Empty;
                scientificPublicationsTxt.Text = string.Empty;
                conservationAndRestorationTxt.Text = string.Empty;
                participationInExhibitionsTxt.Text = string.Empty;
                copiesMadeTxt.Text = string.Empty;
                marriageProtocolAndActOfLiquidationTxt.Text = string.Empty;
                madeTheScientificPassportTxt.Text = string.Empty;
                dateOfCreationOfTheScientificPassportTxt.Text = string.Empty;
                identificationTxt.Text = string.Empty;
                pictureBox.ImageLocation = string.Empty;

                UploadData();


            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно изтриване на {artefactNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            //Премахва от artefactsDataGrid реда, който отговаря на индекса на селектирания ред в него
            foreach (DataGridViewRow item in this.artefactsDataGrid.SelectedRows)
            {
                artefactsDataGrid.Rows.RemoveAt(item.Index);

            }

        }
        private void Artefactscs_Load(object sender, EventArgs e)
        {
            SetFontAndColors();
            UploadData();
            UploadComboBoxDataNameOfMuseum();
            UploadComboBoxDataSections();
            UploadComboBoxTypes();
            UploadComboBoxDataShapes();
            UploadComboBoxDataMaterials();
            UploadComboBoxDataCollections();
            UploadComboBoxDataAssesmentProtocol();
        }

        private void artefactsDataGrid_CellClick(object sender, DataGridViewCellEventArgs e) //Изкарва информацията от избрания ред в DataGridView
        {
            try
            {
                indexTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[0].Value.ToString();
                nameOfMuseumComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[1].Value.ToString();
                sectionsComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[2].Value.ToString();
                collectionscb.Text = artefactsDataGrid.SelectedRows[0].Cells[3].Value.ToString();
                typeComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[4].Value.ToString();
                artefactNameTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[5].Value.ToString();
                cipherTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[6].Value.ToString();
                dateOfAssesmentProtocol.Text = artefactsDataGrid.SelectedRows[0].Cells[7].Value.ToString();
                oldInventoryIdTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[8].Value.ToString();
                idOfActOfAdmissionTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[9].Value.ToString();
                shapeComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[10].Value.ToString();
                materialComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[11].Value.ToString();
                techniqueTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[12].Value.ToString();
                inscriptionOrDateTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[13].Value.ToString();
                sizeTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[14].Value.ToString();
                weightTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[15].Value.ToString();
                eraTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[16].Value.ToString();
                conditionOfArtefactTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[17].Value.ToString();
                amountOfArtefactTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[18].Value.ToString();
                historicalEnquiryTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[19].Value.ToString();
                sellerOrDonaterTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[20].Value.ToString();
                assesmentProtocolIdComboBox.Text = artefactsDataGrid.SelectedRows[0].Cells[21].Value.ToString();
                dateOfRegistration.Text = artefactsDataGrid.SelectedRows[0].Cells[22].Value.ToString();
                priceOfAssesmentProtocolTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[23].Value.ToString();
                storageLocationTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[24].Value.ToString();
                locationOfFindingTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[25].Value.ToString();
                idOfPhotoNegativeTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[26].Value.ToString();
                registrationIdOfNMFTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[27].Value.ToString();
                bibliographicEnquiryTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[28].Value.ToString();
                scientificPublicationsTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[29].Value.ToString();
                conservationAndRestorationTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[30].Value.ToString();
                participationInExhibitionsTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[31].Value.ToString();
                copiesMadeTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[32].Value.ToString();
                marriageProtocolAndActOfLiquidationTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[33].Value.ToString();
                madeTheScientificPassportTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[34].Value.ToString();
                dateOfCreationOfTheScientificPassportTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[35].Value.ToString();
                identificationTxt.Text = artefactsDataGrid.SelectedRows[0].Cells[36].Value.ToString();
                pictureName = artefactsDataGrid.SelectedRows[0].Cells[37].Value.ToString();
                fullDirection = chosenPictureAddress + "\\MuseumPictures\\" + pictureName;
                pictureBox.ImageLocation = fullDirection;


            }
            catch (Exception ex)
            {
                MessageBox.Show("Неуспешно изкарване на данни", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void picturebtn_Click(object sender, EventArgs e) //Добавя снимка към формата в PictureBox
        {
            if (openPictureFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox.ImageLocation = openPictureFileDialog.FileName.ToString();
                pictureName = Path.GetFileName(openPictureFileDialog.FileName);
            }
        }
        private void menubtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Menu
        {
            Menu menu = new Menu();
            Artefacts artefactscs = new Artefacts();
            menu.Show();
            this.Hide();
            artefactscs.Close();
        }

        private void assesmentpridcb_SelectedIndexChanged(object sender, EventArgs e) //Автоматично се запълават dateOfAssesmentProtocol и priceOfAssesmentProtocolTxt с данните от таблицата assesmentprotocol по избрания индекс от assesmentProtocolIdComboBox
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};convert zero datetime=true";
            sqlConn.Open();

            sqlCmd.Connection = sqlConn;
            if (assesmentProtocolIdComboBox.Text != string.Empty)
            {
                string id = assesmentProtocolIdComboBox.SelectedItem.ToString();
                Convert.ToUInt16(id);
                sqlQuery = $"SELECT * FROM rim_dobrich.assesmentprotocol WHERE assesmentpr_id={id}";
                sqlCmd.Parameters.AddWithValue(dateOfAssesmentProtocol.Text, "@assesmentpr_date");
                sqlCmd.Parameters.AddWithValue(priceOfAssesmentProtocolTxt.Text, "@assesmentpr_price");
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                if (sqlRd.Read())
                {
                    if (id != null)
                    {
                        dateOfAssesmentProtocol.Value = sqlRd.GetDateTime("assesmentpr_date");
                        priceOfAssesmentProtocolTxt.Text = sqlRd.GetString("assesmentpr_price");
                    }
                }
            }
            else
            {
                MessageBox.Show("No data");
            }
            sqlConn.Close();
        }
        private void queriesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Queries
        {
            Artefacts artefactscs = new Artefacts();
            Queries queries = new Queries();
            queries.Show();
            artefactscs.Close();
            this.Hide();
        }
        private void sections_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Sections
        {
            Artefacts artefactscs = new Artefacts();
            Sections sections = new Sections();
            sections.Show();
            artefactscs.Close();
            this.Hide();
        }
        private void typesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Types
        {
            Artefacts artefactscs = new Artefacts();
            Types types = new Types();
            types.Show();
            artefactscs.Close();
            this.Hide();
        }
        private void shapesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Shapes
        {
            Artefacts artefactscs = new Artefacts();
            Shapes shapes = new Shapes();
            shapes.Show();
            artefactscs.Close();
            this.Hide();
        }
        private void materialsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Materials
        {
            Artefacts artefactscs = new Artefacts();
            Materials materials = new Materials();
            materials.Show();
            artefactscs.Close();
            this.Hide();
        }
        private void museumsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра NameOfMuseum
        {
            NameOfMuseum name = new NameOfMuseum();
            Artefacts artefactscs = new Artefacts();
            name.Show();
            artefactscs.Close();
            this.Hide();
        }
        private void assesmentProtocolbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра AssesmentProtocol
        {
            Artefacts artefactscs = new Artefacts();
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            assesmentProtocol.Show();
            artefactscs.Close();
            this.Hide();
        }
        private void collectionsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра CollectionsMuseum
        {
            Artefacts artefactscs = new Artefacts();
            CollectionsMuseum collections = new CollectionsMuseum();
            collections.Show();
            artefactscs.Close();
            this.Hide();
        }
        private void searchBtn_Click(object sender, EventArgs e) //Търси по името на артефакта
        {
            try
            {
                DataView dv = sqlDT.DefaultView;
                dv.RowFilter = string.Format("Име like'%{0}%'", searchTxt.Text);
                artefactsDataGrid.DataSource = dv.ToTable();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Неуспешно търсене на данни", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void resetBtn_Click(object sender, EventArgs e) //Връща началните стойности, занулира
        {
            indexTxt.Text = string.Empty;
            nameOfMuseumComboBox.Text = "Име на музей";
            sectionsComboBox.Text = "Отдели";
            collectionscb.Text = "Сбирки";
            typeComboBox.Text = "Видове артефакти";
            artefactNameTxt.Text = string.Empty;
            cipherTxt.Text = string.Empty;
            dateOfAssesmentProtocol.Text = string.Empty;
            oldInventoryIdTxt.Text = string.Empty;
            idOfActOfAdmissionTxt.Text = string.Empty;
            shapeComboBox.Text = "Форма";
            materialComboBox.Text = "Материал";
            techniqueTxt.Text = string.Empty;
            inscriptionOrDateTxt.Text = string.Empty;
            sizeTxt.Text = string.Empty;
            weightTxt.Text = string.Empty;
            eraTxt.Text = string.Empty;
            conditionOfArtefactTxt.Text = string.Empty;
            amountOfArtefactTxt.Text = string.Empty;
            historicalEnquiryTxt.Text = string.Empty;
            sellerOrDonaterTxt.Text = string.Empty;
            assesmentProtocolIdComboBox.Text = "№ ОП";
            dateOfRegistration.Text = string.Empty;
            priceOfAssesmentProtocolTxt.Text = string.Empty;
            storageLocationTxt.Text = string.Empty;
            locationOfFindingTxt.Text = string.Empty;
            idOfPhotoNegativeTxt.Text = string.Empty;
            registrationIdOfNMFTxt.Text = string.Empty;
            bibliographicEnquiryTxt.Text = string.Empty;
            scientificPublicationsTxt.Text = string.Empty;
            conservationAndRestorationTxt.Text = string.Empty;
            participationInExhibitionsTxt.Text = string.Empty;
            copiesMadeTxt.Text = string.Empty;
            marriageProtocolAndActOfLiquidationTxt.Text = string.Empty;
            madeTheScientificPassportTxt.Text = string.Empty;
            dateOfCreationOfTheScientificPassportTxt.Text = string.Empty;
            identificationTxt.Text = string.Empty;
            pictureBox.ImageLocation = string.Empty;
        }

    }
}
