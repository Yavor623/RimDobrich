﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace RIMDobrich1
{
    public partial class Queries : Form
    {
        //Задава стойности и инициализира променливи, нужни за свързване с базата от данни и провеждане на действия в нея 
        Bitmap bitmap;
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlConnection sqlConn1 = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        MySqlCommand sqlCmd1 = new MySqlCommand();

        DataTable sqlDT = new DataTable();
        String sqlQuery;
        MySqlDataAdapter DtA = new MySqlDataAdapter();
        MySqlDataReader sqlRd;
        MySqlDataReader sqlRd1;

        DataSet DS = new DataSet();

        String server = "127.0.0.1";
        String username = "root";
        String password = "";
        String database = "rim_dobrich";

        string queryChoices = "";
        string tableChoices = "";
        string nameColumn = "";
        string bgNameColumn = "";
        string tableName = "";
        int count = 0;
        string indexOfTable = "";
        string singularNameTable = "";
        bool isAssesmentProtocol = false;
        public Queries()
        {
            InitializeComponent();
        }
        //Задава фонта и цвета на dataGridView
        private void SetFontAndColors()
        {
            this.queriesDataGrid.DefaultCellStyle.Font = new Font("Gabriola", 15);
            this.queriesDataGrid.DefaultCellStyle.BackColor = Color.Beige;
            this.queriesDataGrid.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.queriesDataGrid.DefaultCellStyle.SelectionBackColor = Color.NavajoWhite;
            this.queriesDataGrid.GridColor = Color.BlueViolet;
        }
        public void UploadData() //Избира данните от таблицата artefacts плюс данни от другите таблици и ги изкарва в dataGridView
        {

            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};convert zero datetime=true";
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;

            sqlCmd.CommandText = "SELECT id AS 'Номер',rim_dobrich.nameofmuseum.museum_name AS 'Музей',rim_dobrich.sections.section_name AS 'Отдел',rim_dobrich.collections.collection_name AS 'Сбирка' ,rim_dobrich.types.type_name AS 'Вид',artefact_name AS 'Име',cipher AS 'Шифър',dateofregistration AS 'Дата на регистрация',oldinventoryid AS 'Стар инвентарен номер',idofactofadmission AS 'Номер на акт за приемане',rim_dobrich.description.shape_name AS 'Форма',rim_dobrich.materials.material_name AS 'Материал',technology AS 'Техника',inscriptionordate AS 'Надписи или дати', size AS 'Размер',weight AS 'Тегло',era AS 'Епоха',conditionofartefact AS 'Състояние',amountoftheartefact AS 'Брой на артефакта',historicalenquiryid AS 'Историческа справка' ,sellerordonater AS 'Продавач или дарител',assesmentprotocol_id AS 'Номер на оц.протокол' ,rim_dobrich.assesmentprotocol.assesmentpr_date AS 'Дата на оц.протокол',rim_dobrich.assesmentprotocol.assesmentpr_price AS 'Сума на оц.протокол',storagelocation_id AS 'Местосъхранение',locationoffinding AS 'Местонахождение',idofphotonegative AS 'Номер на фотонегатива',registrationidofNMF AS 'Регистрационен номер на НМФ',bibliographicenquiry AS 'Библиографска справка',scientificpublications AS 'Научни публикации',conservationandrestorationid AS 'Консервация и реставрация',participationinexhibitions AS 'Участие в изложби',copiesmade AS 'Направени копия',marriageprotocolandactofliquidation AS 'Протокол за брак и акт за ликвидация',madethescientificpassport AS 'Изготвил научния паспорт',dateofcreationofthescientificpassport AS 'Дата на създаване на НП',identification AS 'Идентификация',pictureaddress AS 'Адрес на снимката' FROM rim_dobrich.artefacts  " +
            "LEFT JOIN rim_dobrich.sections ON rim_dobrich.sections.section_id =rim_dobrich.artefacts.section_id " +
            "LEFT JOIN rim_dobrich.types ON rim_dobrich.types.type_id = rim_dobrich.artefacts.type_id " +
            "LEFT JOIN rim_dobrich.nameofmuseum ON rim_dobrich.nameofmuseum.museum_id = rim_dobrich.artefacts.museum_id " +
            "LEFT JOIN rim_dobrich.description ON rim_dobrich.description.shape_id=rim_dobrich.artefacts.shape_id " +
            "LEFT JOIN rim_dobrich.collections ON rim_dobrich.collections.collection_id = rim_dobrich.artefacts.collection_id " +
            "LEFT JOIN rim_dobrich.assesmentprotocol ON rim_dobrich.assesmentprotocol.assesmentpr_id=rim_dobrich.artefacts.assesmentprotocol_id " +
            "LEFT JOIN rim_dobrich.materials ON rim_dobrich.materials.material_id=rim_dobrich.artefacts.material_id;";

            sqlRd = sqlCmd.ExecuteReader();
            sqlDT.Load(sqlRd);
            sqlRd.Close();
            sqlConn.Close();

            queriesDataGrid.DataSource = sqlDT;


        }
        private void collectionsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра CollectionsMuseum
        {
            Queries queries = new Queries();
            CollectionsMuseum collections = new CollectionsMuseum();
            collections.Show();
            queries.Close();
            this.Hide();
        }

        private void artefactsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Artefacts
        {
            Queries queries = new Queries();
            Artefacts artefactscs = new Artefacts();
            artefactscs.Show();
            queries.Close();
            this.Hide();
        }

        private void sectionsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Sections
        {
            Queries queries = new Queries();
            Sections sections = new Sections();
            sections.Show();
            queries.Close();
            this.Hide();
        }

        private void typesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Types
        {
            Queries queries = new Queries();
            Types types = new Types();
            types.Show();
            queries.Close();
            this.Hide();
        }

        private void shapesbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Shapes
        {
            Queries queries = new Queries();
            Shapes shapes = new Shapes();
            shapes.Show();
            queries.Close();
            this.Hide();
        }

        private void materialsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Materials
        {

            Queries queries = new Queries();
            Materials materials = new Materials();
            materials.Show();
            queries.Close();
            this.Hide();
        }

        private void museumsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра NameOfMuseum
        {
            Queries queries = new Queries();
            NameOfMuseum name = new NameOfMuseum();
            name.Show();
            queries.Close();
            this.Hide();
        }

        private void assesmentProtocolbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра AssesmentProtocol
        {
            Queries queries = new Queries();
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            assesmentProtocol.Show();
            queries.Close();
            this.Hide();
        }

        private void menubtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Menu
        {
            Queries queries = new Queries();
            Menu menu = new Menu();
            menu.Show();

            queries.Close();
            this.Hide();
        }


        private void queryChoice_SelectedIndexChanged(object sender, EventArgs e) //Активира съответните текстбоксове нужни и занулира текстбокса с броя, ако е избрана другата заявка
        {
            switch (queryChoiceComboBox.SelectedIndex + 1)
            {
                case 1:
                    queryChoiceComboBox.Text = "Изберете вида на заявката";
                    typeOfColumnChoiceComboBox.Text = "Изберете критерий за търсене";
                    columnChoiceComboBox.Text = "Изберете колона";

                    typeOfColumnChoiceComboBox.Enabled = true;
                    countTxt.Text = string.Empty;

                    UploadData();
                    break;
                case 2:
                    queriesDataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
                    queriesDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
                    queryChoiceComboBox.Text = "Изберете вида на заявката";
                    typeOfColumnChoiceComboBox.Text = "Изберете критерий за търсене";
                    columnChoiceComboBox.Text = "Изберете колона";
                    columnChoiceComboBox.Items.Clear();
                    columnChoiceComboBox.Enabled = false;

                    typeOfColumnChoiceComboBox.Enabled = true;
                    countTxt.Text = string.Empty;

                    UploadData();
                    break;
                case 3:
                    queriesDataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
                    queriesDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
                    typeOfColumnChoiceComboBox.Items.Clear();

                    queryChoiceComboBox.Text = "Изберете вида на заявката";
                    typeOfColumnChoiceComboBox.Text = "Изберете критерий за търсене";
                    columnChoiceComboBox.Text = "Изберете колона";
                    columnChoiceComboBox.Items.Clear();
                    typeOfColumnChoiceComboBox.Enabled = true;
                    columnChoiceComboBox.Enabled = false;

                    typeOfColumnChoiceComboBox.Items.Add("Шифър");
                    typeOfColumnChoiceComboBox.Items.Add("Техника");
                    typeOfColumnChoiceComboBox.Items.Add("Размер");
                    typeOfColumnChoiceComboBox.Items.Add("Тегло");
                    typeOfColumnChoiceComboBox.Items.Add("Епоха");
                    typeOfColumnChoiceComboBox.Items.Add("Брой на артефакта");
                    typeOfColumnChoiceComboBox.Items.Add("Продавач или дарител");
                    typeOfColumnChoiceComboBox.Items.Add("Местонaхождение");
                    typeOfColumnChoiceComboBox.Items.Add("Изготвил научния паспорт");

                    countTxt.Text = string.Empty;

                    UploadData();
                    break;
            }

        }



        private void columnChoice_SelectedIndexChanged(object sender, EventArgs e) //Променя таблицата и колоната, за която ще се извърши заявката
        {
            countTxt.Text = string.Empty;
            columnChoiceComboBox.Items.Clear();
            if (queryChoiceComboBox.SelectedIndex + 1 == 1 || queryChoiceComboBox.SelectedIndex + 1 == 2)
            {
                searchTxt.Enabled = false;
                searchTxt.PlaceholderText = "Търсачка";
                switch (typeOfColumnChoiceComboBox.SelectedIndex + 1)
                {
                    case 1:
                        nameColumn = "section_name";
                        bgNameColumn = "Секция";
                        tableName = "sections";
                        indexOfTable = "section_id";
                        break;
                    case 2:
                        nameColumn = "collection_name";
                        bgNameColumn = "Колекция";
                        tableName = "collections";
                        indexOfTable = "collection_id";
                        break;
                    case 3:
                        nameColumn = "museum_name";
                        bgNameColumn = "Музей";
                        tableName = "nameofmuseum";
                        indexOfTable = "museum_id";
                        break;
                    case 4:
                        nameColumn = "type_name";
                        bgNameColumn = "Вид";
                        tableName = "types";
                        indexOfTable = "type_id";
                        break;
                    case 5:
                        nameColumn = "shape_name";
                        bgNameColumn = "Форма";
                        tableName = "description";
                        indexOfTable = "shape_id";
                        break;
                    case 6:
                        nameColumn = "material_name";
                        bgNameColumn = "Материал";
                        tableName = "materials";
                        indexOfTable = "material_id";
                        break;

                }
                columnChoiceComboBox.Enabled = true;
                sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database};convert zero datetime=true";

                sqlCmd.CommandText = $"SELECT * FROM rim_dobrich.{tableName}"; //Избира всичко от съответната таблицата 
                sqlConn.Open();
                sqlCmd.Connection = sqlConn;

                MySqlDataReader reader = sqlCmd.ExecuteReader();

                while (reader.Read())
                {
                    columnChoiceComboBox.Items.Add(reader.GetString($"{nameColumn}")); //Добавя елементите от съответната колоната в комбобокса
                }

                sqlConn.Close();
                columnChoiceComboBox.Text = "Изберете колона";
            }
            else
            {
                columnChoiceComboBox.Items.Clear();
                columnChoiceComboBox.Enabled = false;

                switch (typeOfColumnChoiceComboBox.SelectedIndex + 1)
                {
                    case 1:
                        nameColumn = "cipher";
                        bgNameColumn = "Шифър";
                        break;
                    case 2:
                        nameColumn = "technology";
                        bgNameColumn = "Техника";
                        break;
                    case 3:
                        nameColumn = "size";
                        bgNameColumn = "Размер";
                        break;
                    case 4:
                        nameColumn = "weight";
                        bgNameColumn = "Тегло";
                        break;
                    case 5:
                        nameColumn = "era";
                        bgNameColumn = "Епоха";
                        break;
                    case 6:
                        nameColumn = "amountoftheartefact";
                        bgNameColumn = "Брой на артефакта";
                        break;
                    case 7:
                        nameColumn = "sellerordonater";
                        bgNameColumn = "Продавач или дарител";
                        break;
                    case 8:
                        nameColumn = "locationoffinding";
                        bgNameColumn = "Местонaхождение";
                        break;
                    case 9:
                        nameColumn = "madethescientificpassport";
                        bgNameColumn = "Изготвил научния паспорт";
                        break;

                }
                searchTxt.Enabled = true;
                searchTxt.Text = string.Empty;
                searchTxt.PlaceholderText = $"Търси по {bgNameColumn.ToLower()}";
            }


        }

        private void Queries_Load(object sender, EventArgs e)
        {
            SetFontAndColors();
            UploadData();
        }

        private void queriesbtn_Click(object sender, EventArgs e) //Според избраната заявка предприема различни действия
        {
            try
            {
                switch (queryChoiceComboBox.SelectedIndex + 1)
                {
                    case 1:
                        queriesDataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                        sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database}";
                        sqlConn.Open();
                        sqlCmd.CommandText = $"SELECT id AS 'Номер',artefact_name AS 'Име на артефакта',rim_dobrich.{tableName}.{nameColumn} AS '{bgNameColumn}' FROM rim_dobrich.artefacts " +
                        $"LEFT JOIN rim_dobrich.{tableName} ON rim_dobrich.{tableName}.{indexOfTable} = rim_dobrich.artefacts.{indexOfTable} " +
                        $"WHERE rim_dobrich.{tableName}.{nameColumn}='{columnChoiceComboBox.Text}';";

                        sqlCmd.Connection = sqlConn;
                        MySqlDataAdapter da = new MySqlDataAdapter(sqlCmd);
                        DataTable dt = new DataTable();

                        da.Fill(dt);

                        queriesDataGrid.DataSource = dt;
                        sqlConn.Close();
                        break;
                    case 2:
                        sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database}";
                        sqlConn.Open();
                        sqlCmd.CommandText = $"SELECT id AS 'Номер',artefact_name AS 'Име на артефакта',rim_dobrich.{tableName}.{nameColumn} AS '{bgNameColumn}' FROM rim_dobrich.artefacts  " +
                        $"LEFT JOIN rim_dobrich.{tableName} ON rim_dobrich.{tableName}.{indexOfTable} = rim_dobrich.artefacts.{indexOfTable} " +
                        $"WHERE rim_dobrich.{tableName}.{nameColumn}='{columnChoiceComboBox.Text}';";
                        MySqlDataReader reader = sqlCmd.ExecuteReader();
                        while (reader.Read())
                        {
                            count++;
                        }
                        countTxt.Text = count.ToString();
                        sqlConn.Close();
                        break;
                    case 3:

                        try
                        {
                            DataView dv = sqlDT.DefaultView;
                            dv.RowFilter = string.Format("{0} like'%{1}%'", bgNameColumn, searchTxt.Text);
                            queriesDataGrid.DataSource = dv.ToTable();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Неуспешно търсене на данни", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        break;
                }
                count = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно изпълняване на заявката", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void clearBtn_Click(object sender, EventArgs e) //Занулира всичко
        {
            try
            {
                queriesDataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
                queriesDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
                searchTxt.PlaceholderText = "Търсачка";
                searchTxt.Text=string.Empty;
                searchTxt.Enabled = false;
                queryChoiceComboBox.Text = "Изберете вида на заявката";
                typeOfColumnChoiceComboBox.Text = "Изберете критерий за търсене";
                columnChoiceComboBox.Text = "Изберете колона";
                typeOfColumnChoiceComboBox.Enabled = false;
                countTxt.Text = string.Empty;
                UploadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно изчистване на заявката", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }
        private void queryChoiceComboBox_KeyDown(object sender, KeyEventArgs e) //Премахва възможността за редаактиране на текста в combobox-а
        {
            e.SuppressKeyPress = true;
        }
    }
}
