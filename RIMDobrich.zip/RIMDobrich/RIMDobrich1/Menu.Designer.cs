﻿namespace RIMDobrich1
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            shapesBtn = new Button();
            sectionsBtn = new Button();
            menuPanel = new Panel();
            collectionsBtn = new Button();
            queriesBtn = new Button();
            materialsBtn = new Button();
            assesmentProtcolBtn = new Button();
            artefactsBtn = new Button();
            typesBtn = new Button();
            nameOfMuseumBtn = new Button();
            titleLabel = new Label();
            tableChoiceLabel = new Label();
            menuPanel.SuspendLayout();
            SuspendLayout();
            // 
            // shapesBtn
            // 
            shapesBtn.BackColor = Color.NavajoWhite;
            shapesBtn.FlatAppearance.BorderSize = 0;
            shapesBtn.FlatStyle = FlatStyle.Flat;
            shapesBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            shapesBtn.Location = new Point(103, 225);
            shapesBtn.Name = "shapesBtn";
            shapesBtn.Size = new Size(536, 95);
            shapesBtn.TabIndex = 0;
            shapesBtn.Text = "Форми";
            shapesBtn.UseVisualStyleBackColor = false;
            shapesBtn.Click += shapesBtn_Click;
            // 
            // sectionsBtn
            // 
            sectionsBtn.BackColor = Color.NavajoWhite;
            sectionsBtn.FlatAppearance.BorderSize = 0;
            sectionsBtn.FlatStyle = FlatStyle.Flat;
            sectionsBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            sectionsBtn.Location = new Point(668, 100);
            sectionsBtn.Name = "sectionsBtn";
            sectionsBtn.Size = new Size(536, 95);
            sectionsBtn.TabIndex = 1;
            sectionsBtn.Text = "Отдели";
            sectionsBtn.UseVisualStyleBackColor = false;
            sectionsBtn.Click += sectionsbtn_Click;
            // 
            // menuPanel
            // 
            menuPanel.BackColor = Color.Tan;
            menuPanel.Controls.Add(collectionsBtn);
            menuPanel.Controls.Add(queriesBtn);
            menuPanel.Controls.Add(materialsBtn);
            menuPanel.Controls.Add(assesmentProtcolBtn);
            menuPanel.Controls.Add(artefactsBtn);
            menuPanel.Controls.Add(typesBtn);
            menuPanel.Controls.Add(nameOfMuseumBtn);
            menuPanel.Controls.Add(sectionsBtn);
            menuPanel.Controls.Add(shapesBtn);
            menuPanel.Location = new Point(33, 421);
            menuPanel.Name = "menuPanel";
            menuPanel.Size = new Size(1860, 546);
            menuPanel.TabIndex = 2;
            // 
            // collectionsBtn
            // 
            collectionsBtn.BackColor = Color.NavajoWhite;
            collectionsBtn.FlatAppearance.BorderSize = 0;
            collectionsBtn.FlatStyle = FlatStyle.Flat;
            collectionsBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            collectionsBtn.Location = new Point(668, 347);
            collectionsBtn.Name = "collectionsBtn";
            collectionsBtn.Size = new Size(536, 95);
            collectionsBtn.TabIndex = 8;
            collectionsBtn.Text = "Сбирки";
            collectionsBtn.UseVisualStyleBackColor = false;
            collectionsBtn.Click += collectionsBtn_Click;
            // 
            // queriesBtn
            // 
            queriesBtn.BackColor = Color.NavajoWhite;
            queriesBtn.FlatAppearance.BorderSize = 0;
            queriesBtn.FlatStyle = FlatStyle.Flat;
            queriesBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            queriesBtn.Location = new Point(1236, 347);
            queriesBtn.Name = "queriesBtn";
            queriesBtn.Size = new Size(536, 95);
            queriesBtn.TabIndex = 7;
            queriesBtn.Text = "Заявки";
            queriesBtn.UseVisualStyleBackColor = false;
            queriesBtn.Click += queriesbtn_Click;
            // 
            // materialsBtn
            // 
            materialsBtn.BackColor = Color.NavajoWhite;
            materialsBtn.FlatAppearance.BorderSize = 0;
            materialsBtn.FlatStyle = FlatStyle.Flat;
            materialsBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            materialsBtn.Location = new Point(668, 225);
            materialsBtn.Name = "materialsBtn";
            materialsBtn.Size = new Size(536, 95);
            materialsBtn.TabIndex = 6;
            materialsBtn.Text = "Материали";
            materialsBtn.UseVisualStyleBackColor = false;
            materialsBtn.Click += materialsbtn_Click;
            // 
            // assesmentProtcolBtn
            // 
            assesmentProtcolBtn.BackColor = Color.NavajoWhite;
            assesmentProtcolBtn.FlatAppearance.BorderSize = 0;
            assesmentProtcolBtn.FlatStyle = FlatStyle.Flat;
            assesmentProtcolBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtcolBtn.Location = new Point(103, 347);
            assesmentProtcolBtn.Name = "assesmentProtcolBtn";
            assesmentProtcolBtn.Size = new Size(536, 95);
            assesmentProtcolBtn.TabIndex = 5;
            assesmentProtcolBtn.Text = "Оценителен протоколи";
            assesmentProtcolBtn.UseVisualStyleBackColor = false;
            assesmentProtcolBtn.Click += assesmentProtcolBtn_Click;
            // 
            // artefactsBtn
            // 
            artefactsBtn.BackColor = Color.NavajoWhite;
            artefactsBtn.FlatAppearance.BorderSize = 0;
            artefactsBtn.FlatStyle = FlatStyle.Flat;
            artefactsBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            artefactsBtn.Location = new Point(103, 100);
            artefactsBtn.Name = "artefactsBtn";
            artefactsBtn.Size = new Size(536, 95);
            artefactsBtn.TabIndex = 4;
            artefactsBtn.Text = "Артефакти";
            artefactsBtn.UseVisualStyleBackColor = false;
            artefactsBtn.Click += artefactsbtn_Click;
            // 
            // typesBtn
            // 
            typesBtn.BackColor = Color.NavajoWhite;
            typesBtn.FlatAppearance.BorderSize = 0;
            typesBtn.FlatStyle = FlatStyle.Flat;
            typesBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            typesBtn.Location = new Point(1236, 100);
            typesBtn.Name = "typesBtn";
            typesBtn.Size = new Size(536, 95);
            typesBtn.TabIndex = 3;
            typesBtn.Text = "Видове артефакти";
            typesBtn.UseVisualStyleBackColor = false;
            typesBtn.Click += typesbtn_Click;
            // 
            // nameOfMuseumBtn
            // 
            nameOfMuseumBtn.BackColor = Color.NavajoWhite;
            nameOfMuseumBtn.FlatAppearance.BorderSize = 0;
            nameOfMuseumBtn.FlatStyle = FlatStyle.Flat;
            nameOfMuseumBtn.Font = new Font("Cambria", 16.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            nameOfMuseumBtn.Location = new Point(1236, 225);
            nameOfMuseumBtn.Name = "nameOfMuseumBtn";
            nameOfMuseumBtn.Size = new Size(536, 95);
            nameOfMuseumBtn.TabIndex = 2;
            nameOfMuseumBtn.Text = "Музеи";
            nameOfMuseumBtn.UseVisualStyleBackColor = false;
            nameOfMuseumBtn.Click += nameOfMuseumbtn_Click;
            // 
            // titleLabel
            // 
            titleLabel.AutoSize = true;
            titleLabel.Font = new Font("Gabriola", 45.2F, FontStyle.Bold, GraphicsUnit.Point);
            titleLabel.Location = new Point(355, 63);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(1143, 140);
            titleLabel.TabIndex = 3;
            titleLabel.Text = "Добре дошли в системата на РИМ Добрич";
            // 
            // tableChoiceLabel
            // 
            tableChoiceLabel.AutoSize = true;
            tableChoiceLabel.Font = new Font("Gabriola", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point);
            tableChoiceLabel.Location = new Point(514, 228);
            tableChoiceLabel.Name = "tableChoiceLabel";
            tableChoiceLabel.Size = new Size(786, 81);
            tableChoiceLabel.TabIndex = 4;
            tableChoiceLabel.Text = "Изберете таблицата, в която искате да влезете";
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 128);
            ClientSize = new Size(1924, 1055);
            Controls.Add(tableChoiceLabel);
            Controls.Add(titleLabel);
            Controls.Add(menuPanel);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Menu";
            Text = "Меню";
            WindowState = FormWindowState.Maximized;
            menuPanel.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button shapesBtn;
        private Button sectionsBtn;
        private Panel menuPanel;
        private Label titleLabel;
        private Label tableChoiceLabel;
        private Button nameOfMuseumBtn;
        private Button typesBtn;
        private Button artefactsBtn;
        private Button assesmentProtcolBtn;
        private Button materialsBtn;
        private Button queriesBtn;
        private Button collectionsBtn;
    }
}