﻿namespace RIMDobrich1
{
    partial class Types
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Types));
            searchBtn = new Button();
            searchTxt = new TextBox();
            updateBtn = new Button();
            deleteBtn = new Button();
            addNewBtn = new Button();
            typeNameTxt = new TextBox();
            indexTxt = new TextBox();
            typesDataGrid = new DataGridView();
            menuPanel = new Panel();
            assesmentProtocolBtn = new Button();
            collectionsBtn = new Button();
            museumsBtn = new Button();
            artefactsBtn = new Button();
            quieriesBtn = new Button();
            materialsBtn = new Button();
            shapesBtn = new Button();
            typesBtn = new Button();
            sectionsBtn = new Button();
            menuBtn = new Button();
            resetBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)typesDataGrid).BeginInit();
            menuPanel.SuspendLayout();
            SuspendLayout();
            // 
            // searchBtn
            // 
            searchBtn.BackColor = Color.NavajoWhite;
            searchBtn.Cursor = Cursors.Hand;
            searchBtn.FlatStyle = FlatStyle.Flat;
            searchBtn.Font = new Font("Modern No. 20", 19F, FontStyle.Regular, GraphicsUnit.Point);
            searchBtn.Location = new Point(30, 483);
            searchBtn.Name = "searchBtn";
            searchBtn.Size = new Size(667, 60);
            searchBtn.TabIndex = 35;
            searchBtn.Text = "Търси";
            searchBtn.UseVisualStyleBackColor = false;
            searchBtn.Click += searchbtn_Click_1;
            // 
            // searchTxt
            // 
            searchTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            searchTxt.Location = new Point(30, 417);
            searchTxt.Multiline = true;
            searchTxt.Name = "searchTxt";
            searchTxt.PlaceholderText = "Търсене";
            searchTxt.Size = new Size(667, 60);
            searchTxt.TabIndex = 34;
            searchTxt.KeyDown += indexTxt_KeyDown;
            // 
            // updateBtn
            // 
            updateBtn.BackColor = Color.NavajoWhite;
            updateBtn.Cursor = Cursors.Hand;
            updateBtn.FlatStyle = FlatStyle.Flat;
            updateBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            updateBtn.Location = new Point(30, 700);
            updateBtn.Name = "updateBtn";
            updateBtn.Size = new Size(667, 75);
            updateBtn.TabIndex = 33;
            updateBtn.Text = "Обнови";
            updateBtn.UseVisualStyleBackColor = false;
            updateBtn.Click += updatebtn_Click_1;
            // 
            // deleteBtn
            // 
            deleteBtn.BackColor = Color.NavajoWhite;
            deleteBtn.Cursor = Cursors.Hand;
            deleteBtn.FlatStyle = FlatStyle.Flat;
            deleteBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            deleteBtn.Location = new Point(30, 781);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(667, 75);
            deleteBtn.TabIndex = 32;
            deleteBtn.Text = "Премахни";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deletebtn_Click_1;
            // 
            // addNewBtn
            // 
            addNewBtn.BackColor = Color.NavajoWhite;
            addNewBtn.Cursor = Cursors.Hand;
            addNewBtn.FlatStyle = FlatStyle.Flat;
            addNewBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            addNewBtn.Location = new Point(30, 619);
            addNewBtn.Name = "addNewBtn";
            addNewBtn.Size = new Size(667, 75);
            addNewBtn.TabIndex = 31;
            addNewBtn.Text = "Добави";
            addNewBtn.UseVisualStyleBackColor = false;
            addNewBtn.Click += addNewbtn_Click_1;
            // 
            // typeNameTxt
            // 
            typeNameTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            typeNameTxt.Location = new Point(30, 250);
            typeNameTxt.Multiline = true;
            typeNameTxt.Name = "typeNameTxt";
            typeNameTxt.PlaceholderText = "Име на вид";
            typeNameTxt.Size = new Size(667, 60);
            typeNameTxt.TabIndex = 30;
            typeNameTxt.KeyDown += indexTxt_KeyDown;
            // 
            // indexTxt
            // 
            indexTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            indexTxt.Location = new Point(30, 123);
            indexTxt.Multiline = true;
            indexTxt.Name = "indexTxt";
            indexTxt.PlaceholderText = "Индекс";
            indexTxt.Size = new Size(667, 60);
            indexTxt.TabIndex = 29;
            indexTxt.KeyDown += indexTxt_KeyDown;
            // 
            // typesDataGrid
            // 
            typesDataGrid.AllowUserToAddRows = false;
            typesDataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            typesDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            typesDataGrid.BackgroundColor = Color.Tan;
            typesDataGrid.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            typesDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            typesDataGrid.Cursor = Cursors.PanNW;
            typesDataGrid.GridColor = Color.IndianRed;
            typesDataGrid.Location = new Point(731, 91);
            typesDataGrid.Name = "typesDataGrid";
            typesDataGrid.ReadOnly = true;
            typesDataGrid.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = Color.Beige;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            typesDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            typesDataGrid.RowHeadersWidth = 51;
            typesDataGrid.RowTemplate.Height = 29;
            typesDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            typesDataGrid.Size = new Size(1135, 846);
            typesDataGrid.TabIndex = 28;
            typesDataGrid.CellClick += typesDataGrid_CellClick_1;
            // 
            // menuPanel
            // 
            menuPanel.BackColor = Color.Tan;
            menuPanel.Controls.Add(assesmentProtocolBtn);
            menuPanel.Controls.Add(collectionsBtn);
            menuPanel.Controls.Add(museumsBtn);
            menuPanel.Controls.Add(artefactsBtn);
            menuPanel.Controls.Add(quieriesBtn);
            menuPanel.Controls.Add(materialsBtn);
            menuPanel.Controls.Add(shapesBtn);
            menuPanel.Controls.Add(typesBtn);
            menuPanel.Controls.Add(sectionsBtn);
            menuPanel.Controls.Add(menuBtn);
            menuPanel.Location = new Point(0, 0);
            menuPanel.Name = "menuPanel";
            menuPanel.Size = new Size(1933, 38);
            menuPanel.TabIndex = 41;
            // 
            // assesmentProtocolBtn
            // 
            assesmentProtocolBtn.BackColor = Color.NavajoWhite;
            assesmentProtocolBtn.Cursor = Cursors.Hand;
            assesmentProtocolBtn.FlatAppearance.BorderSize = 0;
            assesmentProtocolBtn.FlatStyle = FlatStyle.Flat;
            assesmentProtocolBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtocolBtn.Location = new Point(1364, 0);
            assesmentProtocolBtn.Name = "assesmentProtocolBtn";
            assesmentProtocolBtn.Size = new Size(185, 35);
            assesmentProtocolBtn.TabIndex = 35;
            assesmentProtocolBtn.Text = "Оц. протокол";
            assesmentProtocolBtn.UseVisualStyleBackColor = false;
            assesmentProtocolBtn.Click += assesmentProtocolbtn_Click;
            // 
            // collectionsBtn
            // 
            collectionsBtn.BackColor = Color.NavajoWhite;
            collectionsBtn.Cursor = Cursors.Hand;
            collectionsBtn.FlatAppearance.BorderSize = 0;
            collectionsBtn.FlatStyle = FlatStyle.Flat;
            collectionsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            collectionsBtn.Location = new Point(1555, 0);
            collectionsBtn.Name = "collectionsBtn";
            collectionsBtn.Size = new Size(185, 35);
            collectionsBtn.TabIndex = 34;
            collectionsBtn.Text = "Сбирки";
            collectionsBtn.UseVisualStyleBackColor = false;
            collectionsBtn.Click += collectionsbtn_Click;
            // 
            // museumsBtn
            // 
            museumsBtn.BackColor = Color.NavajoWhite;
            museumsBtn.Cursor = Cursors.Hand;
            museumsBtn.FlatAppearance.BorderSize = 0;
            museumsBtn.FlatStyle = FlatStyle.Flat;
            museumsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            museumsBtn.Location = new Point(1173, 0);
            museumsBtn.Name = "museumsBtn";
            museumsBtn.Size = new Size(185, 35);
            museumsBtn.TabIndex = 33;
            museumsBtn.Text = "Музеи";
            museumsBtn.UseVisualStyleBackColor = false;
            museumsBtn.Click += museumsbtn_Click;
            // 
            // artefactsBtn
            // 
            artefactsBtn.BackColor = Color.NavajoWhite;
            artefactsBtn.Cursor = Cursors.Hand;
            artefactsBtn.FlatAppearance.BorderSize = 0;
            artefactsBtn.FlatStyle = FlatStyle.Flat;
            artefactsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            artefactsBtn.Location = new Point(218, 0);
            artefactsBtn.Name = "artefactsBtn";
            artefactsBtn.Size = new Size(185, 35);
            artefactsBtn.TabIndex = 32;
            artefactsBtn.Text = "Артефакти";
            artefactsBtn.UseVisualStyleBackColor = false;
            artefactsBtn.Click += artefactsbtn_Click;
            // 
            // quieriesBtn
            // 
            quieriesBtn.BackColor = Color.NavajoWhite;
            quieriesBtn.Cursor = Cursors.Hand;
            quieriesBtn.FlatAppearance.BorderSize = 0;
            quieriesBtn.FlatStyle = FlatStyle.Flat;
            quieriesBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            quieriesBtn.Location = new Point(1745, 0);
            quieriesBtn.Name = "quieriesBtn";
            quieriesBtn.Size = new Size(185, 35);
            quieriesBtn.TabIndex = 31;
            quieriesBtn.Text = "Заявки";
            quieriesBtn.UseVisualStyleBackColor = false;
            quieriesBtn.Click += queriesbtn_Click;
            // 
            // materialsBtn
            // 
            materialsBtn.BackColor = Color.NavajoWhite;
            materialsBtn.Cursor = Cursors.Hand;
            materialsBtn.FlatAppearance.BorderSize = 0;
            materialsBtn.FlatStyle = FlatStyle.Flat;
            materialsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            materialsBtn.Location = new Point(982, 0);
            materialsBtn.Name = "materialsBtn";
            materialsBtn.Size = new Size(185, 35);
            materialsBtn.TabIndex = 30;
            materialsBtn.Text = "Материали";
            materialsBtn.UseVisualStyleBackColor = false;
            materialsBtn.Click += materialsbtn_Click;
            // 
            // shapesBtn
            // 
            shapesBtn.BackColor = Color.NavajoWhite;
            shapesBtn.Cursor = Cursors.Hand;
            shapesBtn.FlatAppearance.BorderSize = 0;
            shapesBtn.FlatStyle = FlatStyle.Flat;
            shapesBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            shapesBtn.Location = new Point(791, 0);
            shapesBtn.Name = "shapesBtn";
            shapesBtn.Size = new Size(185, 35);
            shapesBtn.TabIndex = 29;
            shapesBtn.Text = "Форми";
            shapesBtn.UseVisualStyleBackColor = false;
            shapesBtn.Click += shapesbtn_Click;
            // 
            // typesBtn
            // 
            typesBtn.BackColor = Color.NavajoWhite;
            typesBtn.Cursor = Cursors.Hand;
            typesBtn.Enabled = false;
            typesBtn.FlatAppearance.BorderSize = 0;
            typesBtn.FlatStyle = FlatStyle.Flat;
            typesBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            typesBtn.Location = new Point(600, 0);
            typesBtn.Name = "typesBtn";
            typesBtn.Size = new Size(185, 35);
            typesBtn.TabIndex = 28;
            typesBtn.Text = "Видове артефакти";
            typesBtn.UseVisualStyleBackColor = false;
            // 
            // sectionsBtn
            // 
            sectionsBtn.BackColor = Color.NavajoWhite;
            sectionsBtn.Cursor = Cursors.Hand;
            sectionsBtn.FlatAppearance.BorderSize = 0;
            sectionsBtn.FlatStyle = FlatStyle.Flat;
            sectionsBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            sectionsBtn.Location = new Point(409, 0);
            sectionsBtn.Name = "sectionsBtn";
            sectionsBtn.Size = new Size(185, 35);
            sectionsBtn.TabIndex = 2;
            sectionsBtn.Text = "Отдели";
            sectionsBtn.UseVisualStyleBackColor = false;
            sectionsBtn.Click += sectionsbtn_Click;
            // 
            // menuBtn
            // 
            menuBtn.BackColor = Color.NavajoWhite;
            menuBtn.Cursor = Cursors.Hand;
            menuBtn.FlatAppearance.BorderSize = 0;
            menuBtn.FlatStyle = FlatStyle.Flat;
            menuBtn.Font = new Font("Modern No. 20", 16F, FontStyle.Regular, GraphicsUnit.Point);
            menuBtn.Location = new Point(-7, 0);
            menuBtn.Name = "menuBtn";
            menuBtn.Size = new Size(219, 35);
            menuBtn.TabIndex = 0;
            menuBtn.Text = "Меню";
            menuBtn.UseVisualStyleBackColor = false;
            menuBtn.Click += menubtn_Click;
            // 
            // resetBtn
            // 
            resetBtn.BackColor = Color.NavajoWhite;
            resetBtn.Cursor = Cursors.Hand;
            resetBtn.FlatStyle = FlatStyle.Flat;
            resetBtn.Font = new Font("Modern No. 20", 20F, FontStyle.Regular, GraphicsUnit.Point);
            resetBtn.Location = new Point(30, 862);
            resetBtn.Name = "resetBtn";
            resetBtn.Size = new Size(667, 75);
            resetBtn.TabIndex = 42;
            resetBtn.Text = "Изчисти";
            resetBtn.UseVisualStyleBackColor = false;
            resetBtn.Click += resetBtn_Click;
            // 
            // Types
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 205, 153);
            ClientSize = new Size(1902, 1055);
            Controls.Add(indexTxt);
            Controls.Add(resetBtn);
            Controls.Add(menuPanel);
            Controls.Add(searchBtn);
            Controls.Add(searchTxt);
            Controls.Add(updateBtn);
            Controls.Add(deleteBtn);
            Controls.Add(addNewBtn);
            Controls.Add(typeNameTxt);
            Controls.Add(typesDataGrid);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Types";
            Text = "Видове артефакти";
            WindowState = FormWindowState.Maximized;
            Load += Types_Load;
            ((System.ComponentModel.ISupportInitialize)typesDataGrid).EndInit();
            menuPanel.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button searchBtn;
        private TextBox searchTxt;
        private Button updateBtn;
        private Button deleteBtn;
        private Button addNewBtn;
        private TextBox typeNameTxt;
        private TextBox indexTxt;
        private DataGridView typesDataGrid;
        private BindingSource bindingSource1;
        private Panel menuPanel;
        private Button assesmentProtocolBtn;
        private Button collectionsBtn;
        private Button museumsBtn;
        private Button artefactsBtn;
        private Button quieriesBtn;
        private Button materialsBtn;
        private Button shapesBtn;
        private Button typesBtn;
        private Button sectionsBtn;
        private Button menuBtn;
        private Button resetBtn;
    }
}