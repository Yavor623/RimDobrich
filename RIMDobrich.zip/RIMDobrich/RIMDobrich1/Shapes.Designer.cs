﻿namespace RIMDobrich1
{
    partial class Shapes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Shapes));
            shapeIdTxt = new TextBox();
            shapeNameTxt = new TextBox();
            shapeDataGrid = new DataGridView();
            addNewBtn = new Button();
            deleteBtn = new Button();
            updateBtn = new Button();
            menuPanel = new Panel();
            assesmentProtocolBtn = new Button();
            collectionsbtn = new Button();
            museumsBtn = new Button();
            artefactsBtn = new Button();
            quieriesbtn = new Button();
            materialsBtn = new Button();
            shapesBtn = new Button();
            typesBtn = new Button();
            sectionsBtn = new Button();
            menuBtn = new Button();
            resetBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)shapeDataGrid).BeginInit();
            menuPanel.SuspendLayout();
            SuspendLayout();
            // 
            // shapeIdTxt
            // 
            shapeIdTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            shapeIdTxt.Location = new Point(30, 151);
            shapeIdTxt.Multiline = true;
            shapeIdTxt.Name = "shapeIdTxt";
            shapeIdTxt.PlaceholderText = "Индекс";
            shapeIdTxt.Size = new Size(667, 60);
            shapeIdTxt.TabIndex = 0;
            shapeIdTxt.KeyDown += shapeIdTxt_KeyDown;
            // 
            // shapeNameTxt
            // 
            shapeNameTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            shapeNameTxt.Location = new Point(30, 376);
            shapeNameTxt.Multiline = true;
            shapeNameTxt.Name = "shapeNameTxt";
            shapeNameTxt.PlaceholderText = "Име на форма";
            shapeNameTxt.Size = new Size(667, 60);
            shapeNameTxt.TabIndex = 6;
            shapeNameTxt.KeyDown += shapeIdTxt_KeyDown;
            // 
            // shapeDataGrid
            // 
            shapeDataGrid.AccessibleRole = AccessibleRole.None;
            shapeDataGrid.AllowUserToAddRows = false;
            shapeDataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            shapeDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            shapeDataGrid.BackgroundColor = Color.Tan;
            shapeDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            shapeDataGrid.Cursor = Cursors.PanNW;
            shapeDataGrid.Location = new Point(731, 91);
            shapeDataGrid.Name = "shapeDataGrid";
            shapeDataGrid.ReadOnly = true;
            shapeDataGrid.RowHeadersWidth = 51;
            shapeDataGrid.RowTemplate.Height = 29;
            shapeDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            shapeDataGrid.Size = new Size(1135, 846);
            shapeDataGrid.TabIndex = 7;
            shapeDataGrid.CellClick += descriprionDataGrid_CellClick;
            // 
            // addNewBtn
            // 
            addNewBtn.BackColor = Color.NavajoWhite;
            addNewBtn.Cursor = Cursors.Hand;
            addNewBtn.FlatStyle = FlatStyle.Flat;
            addNewBtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            addNewBtn.Location = new Point(30, 619);
            addNewBtn.Name = "addNewBtn";
            addNewBtn.Size = new Size(667, 75);
            addNewBtn.TabIndex = 8;
            addNewBtn.Text = "Добави";
            addNewBtn.UseVisualStyleBackColor = false;
            addNewBtn.Click += addNewbtn_Click;
            // 
            // deleteBtn
            // 
            deleteBtn.BackColor = Color.NavajoWhite;
            deleteBtn.Cursor = Cursors.Hand;
            deleteBtn.FlatStyle = FlatStyle.Flat;
            deleteBtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            deleteBtn.Location = new Point(30, 781);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(667, 75);
            deleteBtn.TabIndex = 9;
            deleteBtn.Text = "Премахни";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Click += deletebtn_Click;
            // 
            // updateBtn
            // 
            updateBtn.BackColor = Color.NavajoWhite;
            updateBtn.Cursor = Cursors.Hand;
            updateBtn.FlatStyle = FlatStyle.Flat;
            updateBtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            updateBtn.Location = new Point(30, 700);
            updateBtn.Name = "updateBtn";
            updateBtn.Size = new Size(667, 75);
            updateBtn.TabIndex = 10;
            updateBtn.Text = "Обнови";
            updateBtn.UseVisualStyleBackColor = false;
            updateBtn.Click += updatebtn_Click;
            // 
            // menuPanel
            // 
            menuPanel.BackColor = Color.Tan;
            menuPanel.Controls.Add(assesmentProtocolBtn);
            menuPanel.Controls.Add(collectionsbtn);
            menuPanel.Controls.Add(museumsBtn);
            menuPanel.Controls.Add(artefactsBtn);
            menuPanel.Controls.Add(quieriesbtn);
            menuPanel.Controls.Add(materialsBtn);
            menuPanel.Controls.Add(shapesBtn);
            menuPanel.Controls.Add(typesBtn);
            menuPanel.Controls.Add(sectionsBtn);
            menuPanel.Controls.Add(menuBtn);
            menuPanel.Location = new Point(0, 0);
            menuPanel.Name = "menuPanel";
            menuPanel.Size = new Size(1933, 38);
            menuPanel.TabIndex = 41;
            // 
            // assesmentProtocolBtn
            // 
            assesmentProtocolBtn.BackColor = Color.NavajoWhite;
            assesmentProtocolBtn.Cursor = Cursors.Hand;
            assesmentProtocolBtn.FlatAppearance.BorderSize = 0;
            assesmentProtocolBtn.FlatStyle = FlatStyle.Flat;
            assesmentProtocolBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtocolBtn.Location = new Point(1364, 0);
            assesmentProtocolBtn.Name = "assesmentProtocolBtn";
            assesmentProtocolBtn.Size = new Size(185, 35);
            assesmentProtocolBtn.TabIndex = 35;
            assesmentProtocolBtn.Text = "Оц. протокол";
            assesmentProtocolBtn.UseVisualStyleBackColor = false;
            assesmentProtocolBtn.Click += assesmentProtocolbtn_Click;
            // 
            // collectionsbtn
            // 
            collectionsbtn.BackColor = Color.NavajoWhite;
            collectionsbtn.Cursor = Cursors.Hand;
            collectionsbtn.FlatAppearance.BorderSize = 0;
            collectionsbtn.FlatStyle = FlatStyle.Flat;
            collectionsbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            collectionsbtn.Location = new Point(1555, 0);
            collectionsbtn.Name = "collectionsbtn";
            collectionsbtn.Size = new Size(185, 35);
            collectionsbtn.TabIndex = 34;
            collectionsbtn.Text = "Сбирки";
            collectionsbtn.UseVisualStyleBackColor = false;
            collectionsbtn.Click += collectionsbtn_Click;
            // 
            // museumsBtn
            // 
            museumsBtn.BackColor = Color.NavajoWhite;
            museumsBtn.Cursor = Cursors.Hand;
            museumsBtn.FlatAppearance.BorderSize = 0;
            museumsBtn.FlatStyle = FlatStyle.Flat;
            museumsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            museumsBtn.Location = new Point(1173, 0);
            museumsBtn.Name = "museumsBtn";
            museumsBtn.Size = new Size(185, 35);
            museumsBtn.TabIndex = 33;
            museumsBtn.Text = "Музеи";
            museumsBtn.UseVisualStyleBackColor = false;
            museumsBtn.Click += museumsbtn_Click;
            // 
            // artefactsBtn
            // 
            artefactsBtn.BackColor = Color.NavajoWhite;
            artefactsBtn.Cursor = Cursors.Hand;
            artefactsBtn.FlatAppearance.BorderSize = 0;
            artefactsBtn.FlatStyle = FlatStyle.Flat;
            artefactsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            artefactsBtn.Location = new Point(218, 0);
            artefactsBtn.Name = "artefactsBtn";
            artefactsBtn.Size = new Size(185, 35);
            artefactsBtn.TabIndex = 32;
            artefactsBtn.Text = "Артефакти";
            artefactsBtn.UseVisualStyleBackColor = false;
            artefactsBtn.Click += artefactsbtn_Click;
            // 
            // quieriesbtn
            // 
            quieriesbtn.BackColor = Color.NavajoWhite;
            quieriesbtn.Cursor = Cursors.Hand;
            quieriesbtn.FlatAppearance.BorderSize = 0;
            quieriesbtn.FlatStyle = FlatStyle.Flat;
            quieriesbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            quieriesbtn.Location = new Point(1745, 0);
            quieriesbtn.Name = "quieriesbtn";
            quieriesbtn.Size = new Size(185, 35);
            quieriesbtn.TabIndex = 31;
            quieriesbtn.Text = "Заявки";
            quieriesbtn.UseVisualStyleBackColor = false;
            quieriesbtn.Click += queriesbtn_Click;
            // 
            // materialsBtn
            // 
            materialsBtn.BackColor = Color.NavajoWhite;
            materialsBtn.Cursor = Cursors.Hand;
            materialsBtn.FlatAppearance.BorderSize = 0;
            materialsBtn.FlatStyle = FlatStyle.Flat;
            materialsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            materialsBtn.Location = new Point(982, 0);
            materialsBtn.Name = "materialsBtn";
            materialsBtn.Size = new Size(185, 35);
            materialsBtn.TabIndex = 30;
            materialsBtn.Text = "Материали";
            materialsBtn.UseVisualStyleBackColor = false;
            materialsBtn.Click += materialsbtn_Click;
            // 
            // shapesBtn
            // 
            shapesBtn.BackColor = Color.NavajoWhite;
            shapesBtn.Cursor = Cursors.Hand;
            shapesBtn.Enabled = false;
            shapesBtn.FlatAppearance.BorderSize = 0;
            shapesBtn.FlatStyle = FlatStyle.Flat;
            shapesBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            shapesBtn.Location = new Point(791, 0);
            shapesBtn.Name = "shapesBtn";
            shapesBtn.Size = new Size(185, 35);
            shapesBtn.TabIndex = 29;
            shapesBtn.Text = "Форми";
            shapesBtn.UseVisualStyleBackColor = false;
            // 
            // typesBtn
            // 
            typesBtn.BackColor = Color.NavajoWhite;
            typesBtn.Cursor = Cursors.Hand;
            typesBtn.FlatAppearance.BorderSize = 0;
            typesBtn.FlatStyle = FlatStyle.Flat;
            typesBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            typesBtn.Location = new Point(600, 0);
            typesBtn.Name = "typesBtn";
            typesBtn.Size = new Size(185, 35);
            typesBtn.TabIndex = 28;
            typesBtn.Text = "Видове артефакти";
            typesBtn.UseVisualStyleBackColor = false;
            typesBtn.Click += typesbtn_Click_1;
            // 
            // sectionsBtn
            // 
            sectionsBtn.BackColor = Color.NavajoWhite;
            sectionsBtn.Cursor = Cursors.Hand;
            sectionsBtn.FlatAppearance.BorderSize = 0;
            sectionsBtn.FlatStyle = FlatStyle.Flat;
            sectionsBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            sectionsBtn.Location = new Point(409, 0);
            sectionsBtn.Name = "sectionsBtn";
            sectionsBtn.Size = new Size(185, 35);
            sectionsBtn.TabIndex = 2;
            sectionsBtn.Text = "Отдели";
            sectionsBtn.UseVisualStyleBackColor = false;
            sectionsBtn.Click += sectionsbtn_Click_1;
            // 
            // menuBtn
            // 
            menuBtn.BackColor = Color.NavajoWhite;
            menuBtn.Cursor = Cursors.Hand;
            menuBtn.FlatAppearance.BorderSize = 0;
            menuBtn.FlatStyle = FlatStyle.Flat;
            menuBtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            menuBtn.Location = new Point(0, 0);
            menuBtn.Name = "menuBtn";
            menuBtn.Size = new Size(212, 35);
            menuBtn.TabIndex = 0;
            menuBtn.Text = "Меню";
            menuBtn.UseVisualStyleBackColor = false;
            menuBtn.Click += menubtn_Click_1;
            // 
            // resetBtn
            // 
            resetBtn.BackColor = Color.NavajoWhite;
            resetBtn.Cursor = Cursors.Hand;
            resetBtn.FlatStyle = FlatStyle.Flat;
            resetBtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            resetBtn.Location = new Point(30, 862);
            resetBtn.Name = "resetBtn";
            resetBtn.Size = new Size(667, 75);
            resetBtn.TabIndex = 42;
            resetBtn.Text = "Изчисти";
            resetBtn.UseVisualStyleBackColor = false;
            resetBtn.Click += resetBtn_Click;
            // 
            // Shapes
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 205, 153);
            ClientSize = new Size(1924, 1055);
            Controls.Add(resetBtn);
            Controls.Add(menuPanel);
            Controls.Add(updateBtn);
            Controls.Add(deleteBtn);
            Controls.Add(addNewBtn);
            Controls.Add(shapeDataGrid);
            Controls.Add(shapeNameTxt);
            Controls.Add(shapeIdTxt);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Shapes";
            Text = "Форми";
            WindowState = FormWindowState.Maximized;
            Load += Description_Load;
            ((System.ComponentModel.ISupportInitialize)shapeDataGrid).EndInit();
            menuPanel.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox shapeIdTxt;
        private TextBox shapeNameTxt;
        private DataGridView shapeDataGrid;
        private Button addNewBtn;
        private Button deleteBtn;
        private Button updateBtn;
        private Panel menuPanel;
        private Button assesmentProtocolBtn;
        private Button collectionsbtn;
        private Button museumsBtn;
        private Button artefactsBtn;
        private Button quieriesbtn;
        private Button materialsBtn;
        private Button shapesBtn;
        private Button typesBtn;
        private Button sectionsBtn;
        private Button menuBtn;
        private Button resetBtn;
    }
}