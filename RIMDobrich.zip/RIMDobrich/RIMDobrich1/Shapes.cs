﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace RIMDobrich1
{
    public partial class Shapes : Form
    {
        //Задава стойности и инициализира променливи, нужни за свързване с базата от данни и провеждане на действия в нея 
        Bitmap bitmap;
        MySqlConnection sqlConn = new MySqlConnection();
        MySqlCommand sqlCmd = new MySqlCommand();
        DataTable sqlDT = new DataTable();
        String sqlQuery;
        MySqlDataAdapter DtA = new MySqlDataAdapter();
        MySqlDataReader sqlRd;

        DataSet DS = new DataSet();

        String server = "127.0.0.1";
        String username = "root";
        String password = "";
        String database = "rim_dobrich";
        public Shapes()
        {
            InitializeComponent();
        }
        //Задава фонта и цвета на dataGridView
        private void SetFontAndColors()
        {
            this.shapeDataGrid.DefaultCellStyle.Font = new Font("Gabriola", 15);
            this.shapeDataGrid.DefaultCellStyle.BackColor = Color.Beige;
            this.shapeDataGrid.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.shapeDataGrid.DefaultCellStyle.SelectionBackColor = Color.NavajoWhite;
            this.shapeDataGrid.GridColor = Color.BlueViolet;
        }
        //Избира данните от таблицата description и ги изкарва в dataGridView
        public void UploadData()
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database}";
            sqlConn.Open();
            sqlCmd.Connection = sqlConn;
            sqlCmd.CommandText = "SELECT shape_id AS 'Индекс', shape_name AS 'Форма' FROM rim_dobrich.description";

            sqlRd = sqlCmd.ExecuteReader();
            sqlDT.Load(sqlRd);

            sqlRd.Close();
            sqlConn.Close();
            shapeDataGrid.DataSource = sqlDT;
        }

        private void addNewbtn_Click(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database}";
            try
            {
                sqlConn.Open();

                //Вмъква в таблицата description съответните стойности
                sqlQuery = $"INSERT INTO rim_dobrich.description(shape_id,shape_name) VALUES('{shapeIdTxt.Text}','{shapeNameTxt.Text}')";

                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();
                MessageBox.Show($"Успешно добавяне на {shapeNameTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                shapeIdTxt.Text = string.Empty;
                shapeNameTxt.Text = string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно добавяне на {shapeNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { sqlConn.Close(); }
            UploadData();
        }

        private void Description_Load(object sender, EventArgs e)
        {
            SetFontAndColors();
            UploadData();
        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            try
            {
                sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database}";
                sqlConn.Open();
                sqlCmd.Connection = sqlConn;

                //Премахва от таблицата description реда, който отговаря на индекса на селектирания ред в dataGridView
                sqlQuery = $"DELETE FROM rim_dobrich.description WHERE shape_id={shapeIdTxt.Text}";
                sqlCmd = new MySqlCommand(sqlQuery, sqlConn);
                sqlRd = sqlCmd.ExecuteReader();
                sqlConn.Close();
                foreach (DataGridViewRow item in this.shapeDataGrid.SelectedRows)
                {
                    shapeDataGrid.Rows.RemoveAt(item.Index);

                }
                MessageBox.Show($"Успешно изтриване на {shapeNameTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                shapeIdTxt.Text = string.Empty;
                shapeNameTxt.Text = string.Empty;

                UploadData();


            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно изтриване на {shapeNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            sqlConn.ConnectionString = $"server={server};user id={username};password={password};database={database}";
            sqlConn.Open();
            try
            {
                MySqlCommand sqlCmd = new MySqlCommand();
                sqlCmd.Connection = sqlConn;

                //Обновява таблицата description 
                sqlCmd.CommandText = $"UPDATE rim_dobrich.description SET shape_id=@shape_id, shape_name=@shape_name  WHERE shape_id=@shape_id";
                sqlCmd.CommandType = CommandType.Text;

                //Стойностите, които ще заменят старите при обновяването
                sqlCmd.Parameters.AddWithValue("@shape_id", shapeIdTxt.Text);
                sqlCmd.Parameters.AddWithValue("@shape_name", shapeNameTxt.Text);
                sqlCmd.ExecuteNonQuery();
                sqlConn.Close();

                MessageBox.Show($"Успешно обновяване на {shapeNameTxt.Text}", "", MessageBoxButtons.OK);

                //Връща началните стойности, занулира
                shapeIdTxt.Text = string.Empty;
                shapeNameTxt.Text = string.Empty;

                UploadData();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно обновяване на {shapeNameTxt.Text}", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void descriprionDataGrid_CellClick(object sender, DataGridViewCellEventArgs e) //Изкарва информацията от избрания ред в DataGridView
        {
            try
            {
                shapeIdTxt.Text = shapeDataGrid.SelectedRows[0].Cells[0].Value.ToString();
                shapeNameTxt.Text = shapeDataGrid.SelectedRows[0].Cells[1].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Неуспешно изкарване на данни", "Грешка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void materialsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Materials
        {
            Shapes shapes = new Shapes();
            Materials materials = new Materials();
            materials.Show();
            shapes.Close();
            this.Hide();
        }

        private void artefactsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Artefacts
        {
            Shapes shapes = new Shapes();
            Artefacts artefactscs = new Artefacts();
            artefactscs.Show();
            shapes.Close();
            this.Hide();
        }

        private void sectionsbtn_Click_1(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Sections
        {
            Shapes shapes = new Shapes();
            Sections sections = new Sections();
            sections.Show();
            shapes.Close();
            this.Hide();
        }

        private void typesbtn_Click_1(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Types
        {
            Shapes description = new Shapes();
            Types types = new Types();
            types.Show();
            description.Close();
            this.Hide();
        }

        private void menubtn_Click_1(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра Menu
        {
            Shapes description = new Shapes();
            Menu menu = new Menu();
            menu.Show();

            description.Close();
            this.Hide();
        }

        private void museumsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра NameOfMuseum
        {
            Shapes description = new Shapes();
            NameOfMuseum name = new NameOfMuseum();
            name.Show();
            description.Close();
            this.Hide();
        }

        private void assesmentProtocolbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра AssesmentProtocol
        {
            Shapes shapes = new Shapes();
            AssesmentProtocol assesmentProtocol = new AssesmentProtocol();
            assesmentProtocol.Show();
            shapes.Close();
            this.Hide();
        }

        private void collectionsbtn_Click(object sender, EventArgs e) //Затваря сегашния формуляр и отваря формуляра CollectionsMuseum
        {
            Shapes shapes = new Shapes();
            CollectionsMuseum collections = new CollectionsMuseum();
            collections.Show();
            shapes.Close();
            this.Hide();
        }
        private void queriesbtn_Click(object sender, EventArgs e)  //Затваря сегашния формуляр и отваря формуляра Queries
        {
            Shapes shapes = new Shapes();
            Queries queries = new Queries();
            queries.Show();
            shapes.Close();
            this.Hide();
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            //Връща началните стойности, занулира
            shapeIdTxt.Text = string.Empty;
            shapeNameTxt.Text = string.Empty;
        }

        private void shapeIdTxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
            }
        }
    }
}
