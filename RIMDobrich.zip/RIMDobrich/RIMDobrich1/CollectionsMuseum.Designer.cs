﻿namespace RIMDobrich1
{
    partial class CollectionsMuseum
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CollectionsMuseum));
            assesmentProtocolbtn = new Button();
            collectionsbtn = new Button();
            museumsbtn = new Button();
            artefactsbtn = new Button();
            quieriesbtn = new Button();
            materialsbtn = new Button();
            shapesbtn = new Button();
            typesbtn = new Button();
            sectionsbtn = new Button();
            menubtn = new Button();
            menuPanel = new Panel();
            updatebtn = new Button();
            deletebtn = new Button();
            addNewbtn = new Button();
            materialDataGrid = new DataGridView();
            collectionNameTxt = new TextBox();
            collectionIdTxt = new TextBox();
            resetBtn = new Button();
            menuPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)materialDataGrid).BeginInit();
            SuspendLayout();
            // 
            // assesmentProtocolbtn
            // 
            assesmentProtocolbtn.BackColor = Color.NavajoWhite;
            assesmentProtocolbtn.Cursor = Cursors.Hand;
            assesmentProtocolbtn.FlatAppearance.BorderSize = 0;
            assesmentProtocolbtn.FlatStyle = FlatStyle.Flat;
            assesmentProtocolbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            assesmentProtocolbtn.Location = new Point(1364, 0);
            assesmentProtocolbtn.Name = "assesmentProtocolbtn";
            assesmentProtocolbtn.Size = new Size(185, 35);
            assesmentProtocolbtn.TabIndex = 35;
            assesmentProtocolbtn.Text = "Оц. протокол";
            assesmentProtocolbtn.UseVisualStyleBackColor = false;
            assesmentProtocolbtn.Click += assesmentProtocolbtn_Click;
            // 
            // collectionsbtn
            // 
            collectionsbtn.BackColor = Color.NavajoWhite;
            collectionsbtn.Cursor = Cursors.Hand;
            collectionsbtn.Enabled = false;
            collectionsbtn.FlatAppearance.BorderSize = 0;
            collectionsbtn.FlatStyle = FlatStyle.Flat;
            collectionsbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            collectionsbtn.Location = new Point(1555, 0);
            collectionsbtn.Name = "collectionsbtn";
            collectionsbtn.Size = new Size(185, 35);
            collectionsbtn.TabIndex = 34;
            collectionsbtn.Text = "Сбирки";
            collectionsbtn.UseVisualStyleBackColor = false;
            // 
            // museumsbtn
            // 
            museumsbtn.BackColor = Color.NavajoWhite;
            museumsbtn.Cursor = Cursors.Hand;
            museumsbtn.FlatAppearance.BorderSize = 0;
            museumsbtn.FlatStyle = FlatStyle.Flat;
            museumsbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            museumsbtn.Location = new Point(1173, 0);
            museumsbtn.Name = "museumsbtn";
            museumsbtn.Size = new Size(185, 35);
            museumsbtn.TabIndex = 33;
            museumsbtn.Text = "Музеи";
            museumsbtn.UseVisualStyleBackColor = false;
            museumsbtn.Click += museumsbtn_Click;
            // 
            // artefactsbtn
            // 
            artefactsbtn.BackColor = Color.NavajoWhite;
            artefactsbtn.Cursor = Cursors.Hand;
            artefactsbtn.FlatAppearance.BorderSize = 0;
            artefactsbtn.FlatStyle = FlatStyle.Flat;
            artefactsbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            artefactsbtn.Location = new Point(218, 0);
            artefactsbtn.Name = "artefactsbtn";
            artefactsbtn.Size = new Size(185, 35);
            artefactsbtn.TabIndex = 32;
            artefactsbtn.Text = "Артефакти";
            artefactsbtn.UseVisualStyleBackColor = false;
            artefactsbtn.Click += artefactsbtn_Click;
            // 
            // quieriesbtn
            // 
            quieriesbtn.BackColor = Color.NavajoWhite;
            quieriesbtn.Cursor = Cursors.Hand;
            quieriesbtn.FlatAppearance.BorderSize = 0;
            quieriesbtn.FlatStyle = FlatStyle.Flat;
            quieriesbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            quieriesbtn.Location = new Point(1745, 0);
            quieriesbtn.Name = "quieriesbtn";
            quieriesbtn.Size = new Size(185, 35);
            quieriesbtn.TabIndex = 31;
            quieriesbtn.Text = "Заявки";
            quieriesbtn.UseVisualStyleBackColor = false;
            quieriesbtn.Click += queriesbtn_Click;
            // 
            // materialsbtn
            // 
            materialsbtn.BackColor = Color.NavajoWhite;
            materialsbtn.Cursor = Cursors.Hand;
            materialsbtn.FlatAppearance.BorderSize = 0;
            materialsbtn.FlatStyle = FlatStyle.Flat;
            materialsbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            materialsbtn.Location = new Point(982, 0);
            materialsbtn.Name = "materialsbtn";
            materialsbtn.Size = new Size(185, 35);
            materialsbtn.TabIndex = 30;
            materialsbtn.Text = "Материали";
            materialsbtn.UseVisualStyleBackColor = false;
            materialsbtn.Click += materialsbtn_Click;
            // 
            // shapesbtn
            // 
            shapesbtn.BackColor = Color.NavajoWhite;
            shapesbtn.Cursor = Cursors.Hand;
            shapesbtn.FlatAppearance.BorderSize = 0;
            shapesbtn.FlatStyle = FlatStyle.Flat;
            shapesbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            shapesbtn.Location = new Point(791, 0);
            shapesbtn.Name = "shapesbtn";
            shapesbtn.Size = new Size(185, 35);
            shapesbtn.TabIndex = 29;
            shapesbtn.Text = "Форми";
            shapesbtn.UseVisualStyleBackColor = false;
            shapesbtn.Click += shapesbtn_Click;
            // 
            // typesbtn
            // 
            typesbtn.BackColor = Color.NavajoWhite;
            typesbtn.Cursor = Cursors.Hand;
            typesbtn.FlatAppearance.BorderSize = 0;
            typesbtn.FlatStyle = FlatStyle.Flat;
            typesbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            typesbtn.Location = new Point(600, 0);
            typesbtn.Name = "typesbtn";
            typesbtn.Size = new Size(185, 35);
            typesbtn.TabIndex = 28;
            typesbtn.Text = "Видове артефакти";
            typesbtn.UseVisualStyleBackColor = false;
            typesbtn.Click += typesbtn_Click;
            // 
            // sectionsbtn
            // 
            sectionsbtn.BackColor = Color.NavajoWhite;
            sectionsbtn.Cursor = Cursors.Hand;
            sectionsbtn.FlatAppearance.BorderSize = 0;
            sectionsbtn.FlatStyle = FlatStyle.Flat;
            sectionsbtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            sectionsbtn.Location = new Point(409, 0);
            sectionsbtn.Name = "sectionsbtn";
            sectionsbtn.Size = new Size(185, 35);
            sectionsbtn.TabIndex = 2;
            sectionsbtn.Text = "Отдели";
            sectionsbtn.UseVisualStyleBackColor = false;
            sectionsbtn.Click += sectionsbtn_Click;
            // 
            // menubtn
            // 
            menubtn.BackColor = Color.NavajoWhite;
            menubtn.Cursor = Cursors.Hand;
            menubtn.FlatAppearance.BorderSize = 0;
            menubtn.FlatStyle = FlatStyle.Flat;
            menubtn.Font = new Font("Modern No. 20", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            menubtn.Location = new Point(0, 0);
            menubtn.Name = "menubtn";
            menubtn.Size = new Size(212, 35);
            menubtn.TabIndex = 0;
            menubtn.Text = "Меню";
            menubtn.UseVisualStyleBackColor = false;
            menubtn.Click += menubtn_Click;
            // 
            // menuPanel
            // 
            menuPanel.BackColor = Color.Tan;
            menuPanel.Controls.Add(assesmentProtocolbtn);
            menuPanel.Controls.Add(collectionsbtn);
            menuPanel.Controls.Add(museumsbtn);
            menuPanel.Controls.Add(artefactsbtn);
            menuPanel.Controls.Add(quieriesbtn);
            menuPanel.Controls.Add(materialsbtn);
            menuPanel.Controls.Add(shapesbtn);
            menuPanel.Controls.Add(typesbtn);
            menuPanel.Controls.Add(sectionsbtn);
            menuPanel.Controls.Add(menubtn);
            menuPanel.Location = new Point(0, 0);
            menuPanel.Name = "menuPanel";
            menuPanel.Size = new Size(1933, 38);
            menuPanel.TabIndex = 52;
            // 
            // updatebtn
            // 
            updatebtn.BackColor = Color.NavajoWhite;
            updatebtn.Cursor = Cursors.Hand;
            updatebtn.FlatStyle = FlatStyle.Flat;
            updatebtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            updatebtn.Location = new Point(30, 700);
            updatebtn.Name = "updatebtn";
            updatebtn.Size = new Size(667, 75);
            updatebtn.TabIndex = 47;
            updatebtn.Text = "Обнови";
            updatebtn.UseVisualStyleBackColor = false;
            updatebtn.Click += updatebtn_Click;
            // 
            // deletebtn
            // 
            deletebtn.BackColor = Color.NavajoWhite;
            deletebtn.Cursor = Cursors.Hand;
            deletebtn.FlatStyle = FlatStyle.Flat;
            deletebtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            deletebtn.Location = new Point(30, 781);
            deletebtn.Name = "deletebtn";
            deletebtn.Size = new Size(667, 75);
            deletebtn.TabIndex = 46;
            deletebtn.Text = "Премахни";
            deletebtn.UseVisualStyleBackColor = false;
            deletebtn.Click += deletebtn_Click;
            // 
            // addNewbtn
            // 
            addNewbtn.BackColor = Color.NavajoWhite;
            addNewbtn.Cursor = Cursors.Hand;
            addNewbtn.FlatStyle = FlatStyle.Flat;
            addNewbtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            addNewbtn.Location = new Point(30, 619);
            addNewbtn.Name = "addNewbtn";
            addNewbtn.Size = new Size(667, 75);
            addNewbtn.TabIndex = 45;
            addNewbtn.Text = "Добави";
            addNewbtn.UseVisualStyleBackColor = false;
            addNewbtn.Click += addNewbtn_Click;
            // 
            // materialDataGrid
            // 
            materialDataGrid.AccessibleRole = AccessibleRole.None;
            materialDataGrid.AllowUserToAddRows = false;
            materialDataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            materialDataGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            materialDataGrid.BackgroundColor = Color.Tan;
            materialDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            materialDataGrid.Cursor = Cursors.PanNW;
            materialDataGrid.Location = new Point(731, 91);
            materialDataGrid.MultiSelect = false;
            materialDataGrid.Name = "materialDataGrid";
            materialDataGrid.ReadOnly = true;
            materialDataGrid.RowHeadersWidth = 51;
            materialDataGrid.RowTemplate.Height = 29;
            materialDataGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            materialDataGrid.Size = new Size(1135, 846);
            materialDataGrid.TabIndex = 44;
            materialDataGrid.CellClick += materialDataGrid_CellClick;
            // 
            // collectionNameTxt
            // 
            collectionNameTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            collectionNameTxt.Location = new Point(30, 376);
            collectionNameTxt.Multiline = true;
            collectionNameTxt.Name = "collectionNameTxt";
            collectionNameTxt.PlaceholderText = "Име на сбирка";
            collectionNameTxt.Size = new Size(667, 60);
            collectionNameTxt.TabIndex = 43;
            collectionNameTxt.KeyDown += collectionNameTxt_KeyDown;
            // 
            // collectionIdTxt
            // 
            collectionIdTxt.Font = new Font("Segoe UI", 19F, FontStyle.Regular, GraphicsUnit.Point);
            collectionIdTxt.Location = new Point(30, 151);
            collectionIdTxt.Multiline = true;
            collectionIdTxt.Name = "collectionIdTxt";
            collectionIdTxt.PlaceholderText = "Индекс";
            collectionIdTxt.Size = new Size(667, 60);
            collectionIdTxt.TabIndex = 42;
            collectionIdTxt.KeyDown += collectionIdTxt_KeyDown;
            // 
            // resetBtn
            // 
            resetBtn.BackColor = Color.NavajoWhite;
            resetBtn.Cursor = Cursors.Hand;
            resetBtn.FlatStyle = FlatStyle.Flat;
            resetBtn.Font = new Font("Modern No. 20", 19.7999973F, FontStyle.Regular, GraphicsUnit.Point);
            resetBtn.Location = new Point(30, 862);
            resetBtn.Name = "resetBtn";
            resetBtn.Size = new Size(667, 75);
            resetBtn.TabIndex = 53;
            resetBtn.Text = "Изчисти";
            resetBtn.UseVisualStyleBackColor = false;
            resetBtn.Click += resetBtn_Click;
            // 
            // CollectionsMuseum
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 205, 153);
            ClientSize = new Size(1902, 1055);
            Controls.Add(resetBtn);
            Controls.Add(menuPanel);
            Controls.Add(updatebtn);
            Controls.Add(deletebtn);
            Controls.Add(addNewbtn);
            Controls.Add(materialDataGrid);
            Controls.Add(collectionNameTxt);
            Controls.Add(collectionIdTxt);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "CollectionsMuseum";
            Text = "Сбирки";
            Load += Collections_Load;
            menuPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)materialDataGrid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button assesmentProtocolbtn;
        private Button collectionsbtn;
        private Button museumsbtn;
        private Button artefactsbtn;
        private Button quieriesbtn;
        private Button materialsbtn;
        private Button shapesbtn;
        private Button typesbtn;
        private Button sectionsbtn;
        private Button menubtn;
        private Panel menuPanel;
        private Button updatebtn;
        private Button deletebtn;
        private Button addNewbtn;
        private DataGridView materialDataGrid;
        private TextBox collectionNameTxt;
        private TextBox collectionIdTxt;
        private Button resetBtn;
    }
}